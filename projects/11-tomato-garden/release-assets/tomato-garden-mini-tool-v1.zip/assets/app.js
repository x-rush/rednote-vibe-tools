(() => {
'use strict';
const STORAGE_KEY = 'tomato-garden-v1';
function freshState() {
  return { version: 1, selected: 'tomato', progress: {}, total: 0, records: [], collection: [], session: null };
}
function stageOf(plant, minutes) {
  return plant.stages.reduce((stage, item, index) => minutes >= item.at ? index : stage, 0);
}
function remaining(session, now) {
  if (!session) return 0;
  return Math.max(0, session.status === 'paused' ? session.left : Math.min(session.duration, session.end - now));
}
function startSession(state, { id, minutes, task, mode = 'focus', now }) {
  if (state.session || !Number.isSafeInteger(minutes) || minutes <= 0) return state;
  return { ...state, session: { id, plantId: state.selected, task, mode, duration: minutes * 60000, left: minutes * 60000, end: now + minutes * 60000, status: 'running' } };
}
function togglePause(state, now) {
  const session = state.session;
  if (!session) return state;
  const left = remaining(session, now);
  return { ...state, session: { ...session, left, status: session.status === 'paused' ? 'running' : 'paused', end: now + left } };
}
function settle(state, now, plants) {
  const session = state.session;
  if (!session) return { state, result: null };
  const complete = remaining(session, now) === 0;
  if (session.mode === 'rest') return { state: { ...state, session: null }, result: { rest: true, complete } };
  if (state.records.some(record => record.id === session.id)) return { state: { ...state, session: null }, result: null };
  const minutes = Math.floor((session.duration - remaining(session, now)) / 60000);
  const plant = plants.find(item => item.id === session.plantId);
  const previous = state.progress[plant.id] || 0;
  const progress = Math.min(plant.stages.at(-1).at, previous + minutes);
  const record = { id: session.id, task: session.task, plantId: plant.id, minutes, complete, at: now };
  return { state: { ...state, session: null, total: state.total + minutes, progress: { ...state.progress, [plant.id]: progress }, records: minutes || complete ? [...state.records, record] : state.records }, result: { minutes, complete, plantId: plant.id, stage: stageOf(plant, progress) } };
}
function collect(state, plants, now, id) {
  const plant = plants.find(item => item.id === state.selected);
  if (state.session || (state.progress[plant.id] || 0) < plant.stages.at(-1).at) return state;
  return { ...state, progress: { ...state.progress, [plant.id]: 0 }, collection: [...state.collection, { id, plantId: plant.id, at: now, minutes: plant.stages.at(-1).at }] };
}
function localDay(timestamp) {
  const date = new Date(timestamp);
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
}
function restore(raw, plants) {
  const state = JSON.parse(raw);
  const ids = plants.map(plant => plant.id);
  const number = value => Number.isFinite(value) && value >= 0;
  if (!state || state.version !== 1 || !ids.includes(state.selected) || !number(state.total) || !state.progress || !Array.isArray(state.records) || !Array.isArray(state.collection)) throw Error('Invalid state');
  if (plants.find(p => p.id === state.selected).unlock > state.total) throw Error('Locked plant');
  for (const [id, value] of Object.entries(state.progress)) if (!ids.includes(id) || !number(value) || value > plants.find(p => p.id === id).stages.at(-1).at) throw Error('Invalid progress');
  for (const record of state.records) if (!ids.includes(record.plantId) || typeof record.id !== 'string' || typeof record.task !== 'string' || !number(record.minutes) || !number(record.at) || typeof record.complete !== 'boolean') throw Error('Invalid record');
  for (const item of state.collection) if (!ids.includes(item.plantId) || typeof item.id !== 'string' || !number(item.at) || !number(item.minutes)) throw Error('Invalid collection');
  const s = state.session;
  if (s && (!ids.includes(s.plantId) || !['focus', 'rest'].includes(s.mode) || !['running', 'paused'].includes(s.status) || !number(s.duration) || s.duration === 0 || !number(s.left) || s.left > s.duration || !number(s.end) || typeof s.id !== 'string' || typeof s.task !== 'string')) throw Error('Invalid session');
  return state;
}

const leaf = (x, y, angle = 0, size = 1, color = '#567e4b') => `<path d="M0 0C-34-3-43-39-39-43C-10-48 8-20 0 0Z" fill="${color}" transform="translate(${x} ${y}) rotate(${angle}) scale(${size})"/><path d="m0 0-29-33" stroke="#edf0cd" stroke-width="1.2" opacity=".35" transform="translate(${x} ${y}) rotate(${angle}) scale(${size})"/>`;
const flower = (x, y, color, scale = 1) => `<g transform="translate(${x} ${y}) scale(${scale})">${Array.from({ length: 8 }, (_, i) => `<ellipse cy="-13" rx="6" ry="12" fill="${color}" transform="rotate(${i * 45})"/>`).join('')}<circle r="9" fill="#805333"/><circle r="5" fill="#a87536"/></g>`;
const fruit = (x, y, strawberry = false) => `<g transform="translate(${x} ${y})">${strawberry ? '<path d="M-13-6Q-19 5 0 24Q19 5 13-6Q5-12 0-7Q-6-12-13-6Z" fill="#c65151"/><path d="m-7 0 1 2m8 0 1 2m-7 5 1 2m7 0 1 2m-6 5 1 2" stroke="#f7ce82" stroke-width="2"/>' : '<path d="M0-10C-29-23-32 22-8 26C-2 28 5 28 11 24C33 12 22-22 0-10Z" fill="#c64e37"/><ellipse cx="-10" cy="0" rx="4" ry="7" fill="#ef9b72" opacity=".7"/>'}<path d="m0-5-10-9 9 3 2-9 3 9 10-3-10 9Z" fill="#436d3c"/></g>`;
function foliage(id, stage) {
  if (stage === 0) return '<g class="seed-effort"><path d="M150 238v-22" stroke="#7d9b61" stroke-width="3" fill="none"/><path d="M150 225q-15-1-14-13 14 0 14 13m0-4q0-13 12-13 2 12-12 13" fill="#91ad75"/></g><path d="M145 239q5-9 10 0" fill="none" stroke="#bca070" stroke-width="3"/><circle cx="157" cy="235" r="2" fill="#d7ba8b"/>';
  if (stage === 1) return `<path d="M150 238V203" stroke="#597642" stroke-width="4" fill="none"/>${leaf(150, 213, -20, .55)}${leaf(150, 206, 95, .48, '#7e9b56')}`;
  if (id === 'cactus') {
    return `<path d="M129 238V163a21 21 0 0 1 42 0v75" fill="#73926a"/><path d="M143 237V161m15 76v-77" stroke="#adc392" stroke-width="3" fill="none"/>${stage >= 3 ? '<path d="M132 214h-14q-13 0-13-14v-17a9 9 0 0 1 18 0v13h9m35 4h15v-25a9 9 0 0 1 18 0v29q0 14-17 14h-16" fill="#84a074"/>' : ''}<path d="m129 173-5-2m6 19-5 2m47-17 5-2m-5 25 5 2m-27-35 3 2m-3 17 3 2m-3 20 3 2m-3 18 3 2" stroke="#e7e6b9" stroke-width="2"/>${stage === 4 ? flower(151, 145, '#d898a2', .75) : ''}`;
  }
  if (id === 'mint') {
    return `<path d="M150 239V143m0 67-28-30m28 23 27-37" stroke="#588257" stroke-width="4" fill="none"/>${[0,1,2].map(i => leaf(149, 226-i*30, -15, .7-i*.1, '#5f905f') + leaf(151, 221-i*30, 105, .75-i*.1, '#88a975')).join('')}${stage >= 3 ? leaf(124, 183, -20, .7, '#6c9d6b') + leaf(176, 174, 100, .8, '#739969') : ''}${stage === 4 ? leaf(150, 150, 20, .6, '#a4bb7a') + leaf(126, 219, -65, .65) : ''}`;
  }
  if (id === 'lavender') {
    return `${[[-30,160],[-14,130],[5,115],[24,143],[38,171]].map(([dx,y],i) => `<path d="M150 240Q${150+dx} 210 ${150+dx} ${y}" stroke="#789274" stroke-width="3" fill="none"/>${leaf(150+dx*.6, 210, dx < 0 ? -20 : 100, .5, '#91a18a')}${stage >= 3 ? `<g transform="translate(${150+dx} ${y})">${Array.from({length:stage === 4 ? 5 : 2},(_,j) => `<ellipse cx="${j%2 ? 3 : -3}" cy="${-j*7}" rx="6" ry="8" fill="${i%2 ? '#a18db3' : '#86739e'}"/>`).join('')}</g>` : ''}`).join('')}`;
  }
  if (id === 'daisy') {
    return `${leaf(150,235,-25,.85,'#7e9a68')}${leaf(152,234,105,.9,'#8da573')}${[[120,157],[158,128],[188,178]].map(([x,y]) => `<path d="M150 239Q${x-12} 200 ${x} ${y}" stroke="#799267" stroke-width="3" fill="none"/>${stage === 4 ? flower(x,y,'#fffdf2',.9).replaceAll('#805333','#d5ad51').replaceAll('#a87536','#ebc765') : stage === 3 ? `<ellipse cx="${x}" cy="${y}" rx="7" ry="10" fill="#97a275"/>` : ''}`).join('')}`;
  }
  if (id === 'monstera') {
    return `<g stroke="#496540" stroke-width="4" fill="none"><path d="M150 239Q135 171 113 145M150 239Q178 187 201 132M150 239V109"/></g>${leaf(150, 122, 15, 1.3, '#385f43')}${leaf(120, 163, -35, 1.55)}${leaf(180, 170, 100, 1.6, '#668b56')}${stage > 2 ? '<g stroke="#c9d4a7" stroke-width="5" stroke-linecap="round"><path d="m85 134 17 4m-15 8 20 4m99-35-14 15m20-1-13 13m-65-42 13 7m-12 7 14 7"/></g>' : ''}${stage === 4 ? leaf(150, 215, 80, 1.2, '#345a3b') + leaf(139, 212, -40, 1.1, '#78964e') : ''}`;
  }
  if (id === 'strawberry') {
    return `<path d="M150 240V175m0 52-37-35m37 26 34-39" fill="none" stroke="#547244" stroke-width="4"/>${leaf(150, 190, 38, 1)}${leaf(140, 211, -42, .95)}${leaf(167, 204, 102, 1)}${leaf(146, 227, -80, .75, '#78964e')}${stage >= 3 ? flower(124, 180, '#fffbed', .6) + flower(183, 172, '#fffbed', .5) : ''}${stage === 4 ? '<path d="M165 203q34-16 34 22M131 218q-34-18-31 19" stroke="#698447" stroke-width="3" fill="none"/>' + fruit(199, 230, true) + fruit(100, 243, true) : ''}`;
  }
  const top = id === 'sunflower' ? 86 : 126;
  return `<path d="M150 239V${top}M150 186l-30-25M150 163l32-24" fill="none" stroke="#567442" stroke-width="5" stroke-linecap="round"/>${leaf(148, 211, -30, .9)}${leaf(151, 188, 100, .9, '#78964e')}${leaf(129, 168, -8, .7)}${leaf(175, 145, 105, .65, '#6b8b4d')}${id === 'sunflower' ? (stage === 3 ? '<ellipse cx="150" cy="91" rx="17" ry="22" fill="#7d9142"/><path d="m143 99 7-27 5 28" fill="#c6a144"/>' : stage === 4 ? flower(150, 87, '#e5b747', 1.65) : leaf(150, 113, 40, .6)) : (stage >= 3 ? flower(149, 119, '#e6bf53', .45) + flower(191, 136, '#e6bf53', .35) : '') + (stage === 4 ? fruit(120, 188) + fruit(182, 170) : '')}`;
}
function plantArt(id, stage = 0, scene = false) {
  return `<svg viewBox="0 0 300 330" aria-hidden="true" class="plant-art">${scene ? '<path class="scene-sky" d="M42 265V102a108 108 0 0 1 216 0v163Z" fill="#e6ead6"/><path d="M50 255V104a100 100 0 0 1 200 0v151M150 5v239M46 130h208" fill="none" stroke="#f8f7ee" stroke-width="8"/><circle class="scene-sun" cx="221" cy="62" r="28" fill="#f1d8a0"/><path d="M48 235q47-76 110-15t94-28v68H48Z" fill="#d8dfc3"/><path d="M20 277h260" stroke="#d5cdb6" stroke-width="3" stroke-linecap="round"/>' : ''}<ellipse cx="150" cy="310" rx="69" ry="9" fill="#384326" opacity=".09"/><path d="m109 246 11 53q30 15 60 0l11-53Z" fill="#c37b54"/><path d="m119 249 10 48q9 6 17 7l-3-55Z" fill="#d99970"/><path d="m177 249-7 54 10-4 11-53Z" fill="#a85e40"/><rect x="104" y="237" width="92" height="17" rx="5" fill="#d49169"/><ellipse cx="150" cy="238" rx="43" ry="7" fill="#745437"/><g class="living-foliage">${foliage(id, stage)}</g><path d="M133 273h34" stroke="#e9be96" stroke-width="2" stroke-linecap="round" opacity=".5"/></svg>`;
}
const icons = {
  play: '<path d="m9 5 11 7-11 7Z"/>',
  stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  expand: '<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',
  collapse: '<path d="M3 8h5V3m8 0v5h5M8 21v-5H3m13 5v-5h5"/>',
  moon: '<path d="M20 14A8 8 0 0 1 10 4a8 8 0 1 0 10 10Z"/>',
  timer: '<circle cx="12" cy="13" r="8"/><path d="M9 2h6m-3 7v5l3 2"/>',
  garden: '<path d="M12 19V9m0 5C4 14 3 9 4 5c6-1 9 3 8 9Zm0-4c0-5 4-7 8-6 1 5-2 8-8 8M5 21h14"/>',
  book: '<path d="M12 5c-3-2-6-2-9-1v15c3-1 6-1 9 1 3-2 6-2 9-1V4c-3-1-6-1-9 1Zm0 0v15"/>',
  arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  lock: '<rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 4v3"/>',
};
const icon = name => `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.garden}</svg>`;

const content = {"brand":{"name":"番茄小院","en":"THE LITTLE GARDEN","tagline":"把认真度过的时间，种成喜欢的样子。"},"timing":{"presets":[15,25,45],"default":25,"rest":5,"longRest":15,"min":1,"max":180},"plants":[{"id":"tomato","name":"小番茄","latin":"Solanum lycopersicum","kind":"结果植物","color":"#c64e37","unlock":0,"description":"从第一片嫩叶，到枝头的一抹红。适合你的第一段专注。","stages":[{"name":"种子","at":0,"note":"一颗小种子，等一段认真时光。"},{"name":"萌芽","at":15,"note":"两片嫩芽探出土面。"},{"name":"展叶","at":50,"note":"枝条伸长，新叶舒展开来。"},{"name":"开花","at":100,"note":"小小的黄色星花，开在枝头。"},{"name":"结果","at":150,"note":"红番茄成熟了，认真有了形状。"}]},{"id":"sunflower","name":"向日葵","latin":"Helianthus annuus","kind":"观花植物","color":"#c99a30","unlock":60,"description":"向着光慢慢长高，把每次投入变成一朵明亮的花。","stages":[{"name":"种子","at":0,"note":"把一点期待，种进土里。"},{"name":"萌芽","at":15,"note":"圆圆的子叶迎接阳光。"},{"name":"拔高","at":60,"note":"茎秆长高，大叶子舒展开。"},{"name":"花苞","at":120,"note":"顶端的小花苞，正在积蓄力量。"},{"name":"盛放","at":180,"note":"金黄花盘打开，今天也有好阳光。"}]},{"id":"strawberry","name":"草莓","latin":"Fragaria × ananassa","kind":"结果植物","color":"#b85460","unlock":180,"description":"低低的叶丛里藏着小惊喜，慢慢积攒自己的甜。","stages":[{"name":"种子","at":0,"note":"甜甜的期待，从这里开始。"},{"name":"萌芽","at":20,"note":"一株小芽冒出了头。"},{"name":"簇叶","at":70,"note":"三片一组的叶子渐渐茂密。"},{"name":"白花","at":140,"note":"白色小花躲在叶子之间。"},{"name":"红果","at":210,"note":"垂下的红草莓，是时间的回礼。"}]},{"id":"monstera","name":"龟背竹","latin":"Monstera deliciosa","kind":"观叶植物","color":"#426340","unlock":360,"description":"从一片心形叶，到舒展的绿意。为长久的专注留一个位置。","stages":[{"name":"种子","at":0,"note":"给一片未来的绿意留个位置。"},{"name":"萌芽","at":20,"note":"卷着的小叶，正在慢慢醒来。"},{"name":"心叶","at":80,"note":"完整的心形叶舒展开来。"},{"name":"初裂","at":160,"note":"新叶开始出现独特的裂口。"},{"name":"繁叶","at":240,"note":"层层绿叶，长成小院安静的一角。"}]},{"id":"mint","name":"薄荷","latin":"Mentha","kind":"香草植物","color":"#6b9566","unlock":0,"description":"清新的小叶片，陪你从十分钟开始。","stages":[{"name":"种子","at":0,"note":"小种子已就位，开始一段属于你的时间。"},{"name":"新芽","at":10,"note":"嫩芽探出头，每一点投入都有回应。"},{"name":"对叶","at":25,"note":"绿意正在舒展，慢慢来也很好。"},{"name":"分枝","at":55,"note":"离盛放更近了，给期待一点时间。"},{"name":"清香","at":90,"note":"这株植物长成了，把它收藏进小院吧。"}]},{"id":"cactus","name":"仙人掌","latin":"Cactaceae","kind":"观叶植物","color":"#79966c","unlock":0,"description":"不急着长高，也能开出自己的小花。","stages":[{"name":"种子","at":0,"note":"小种子已就位，开始一段属于你的时间。"},{"name":"冒芽","at":10,"note":"嫩芽探出头，每一点投入都有回应。"},{"name":"圆茎","at":35,"note":"绿意正在舒展，慢慢来也很好。"},{"name":"侧芽","at":75,"note":"离盛放更近了，给期待一点时间。"},{"name":"开花","at":120,"note":"这株植物长成了，把它收藏进小院吧。"}]},{"id":"lavender","name":"薰衣草","latin":"Lavandula","kind":"香草植物","color":"#9580aa","unlock":120,"description":"一簇紫色的安静，留给沉浸其中的你。","stages":[{"name":"种子","at":0,"note":"小种子已就位，开始一段属于你的时间。"},{"name":"萌芽","at":15,"note":"嫩芽探出头，每一点投入都有回应。"},{"name":"细叶","at":50,"note":"绿意正在舒展，慢慢来也很好。"},{"name":"花穗","at":110,"note":"离盛放更近了，给期待一点时间。"},{"name":"紫花","at":180,"note":"这株植物长成了，把它收藏进小院吧。"}]},{"id":"daisy","name":"小雏菊","latin":"Bellis perennis","kind":"观花植物","color":"#d1ad5e","unlock":240,"description":"在普通的日子里，种出小小的明亮。","stages":[{"name":"种子","at":0,"note":"小种子已就位，开始一段属于你的时间。"},{"name":"萌芽","at":15,"note":"嫩芽探出头，每一点投入都有回应。"},{"name":"叶丛","at":45,"note":"绿意正在舒展，慢慢来也很好。"},{"name":"花苞","at":95,"note":"离盛放更近了，给期待一点时间。"},{"name":"花开","at":150,"note":"这株植物长成了，把它收藏进小院吧。"}]}],"ui":{"nav":["专注时光","我的小院","成长手记"],"eyebrow":"留一点时间，给自己","focusTitle":"今天，种下一点认真。","taskLabel":"这段时间，想完成什么？","taskPlaceholder":"读几页书、写一段文字……","taskDefault":"一段专注时光","minutes":"分钟","growth":"成长","start":"开始专注","pause":"暂停","resume":"继续专注","finish":"提前结束","rest":"休息 5 分钟","skipRest":"结束休息","back":"回到小院","again":"再专注一次","growing":"正在生长","ready":"等待下一段时光","paused":"歇一歇，回来接着长","focusing":"把注意力，留给眼前的事","resting":"休息一下，让思绪透透气","today":"今日专注","sessions":"完整番茄","total":"累计专注","stage":"生长进度","next":"距离下一阶段","mature":"已经长成，可以收入小院了","collect":"收入小院，种下一株","collected":"已收入小院。选一颗新的种子吧。","seedTitle":"挑一颗喜欢的种子","seedIntro":"成长时间是小院里的游戏设定，不是现实种植周期。","select":"种下它","selected":"正在培养","locked":"累计专注 {n} 分钟解锁","replace":"当前植物的进度会保留，下次可以继续培养。","gardenTitle":"努力过的时间，都在这里。","gardenSubtitle":"一盆一盆，慢慢长成你的小院。","collection":"小院收藏","emptyGarden":"小院还很安静","emptyGardenNote":"完成第一株植物的培养，就能把它留在这里。","journalTitle":"每一点认真，都算数。","week":"最近七天","recent":"最近的专注","emptyRecords":"第一段专注，正等着你写下。","complete":"完整专注","partial":"提前结束","success":"这段认真，已经长进小院。","restDone":"休息结束，带着好精神回来。","earned":"本次收获","stageReached":"现在的模样","close":"关闭","finishTitle":"要结束这段专注吗？","finishNote":"已完成的整分钟会保留为成长，未完成的番茄不计入完整次数。","confirmFinish":"结束并保留成长","cancel":"继续当前计时","storageError":"浏览器暂时无法保存。当前可继续使用，关闭页面后进度可能丢失。","storageReset":"本地记录无法读取，已开启新的小院。","local":"进度保存在当前浏览器","localDetail":"换设备不会同步，清理浏览器数据会清除小院。","saved":"安静生长，不必赶时间","plantDetail":"植物图鉴","minuteShort":"分","newPlant":"挑选植物","fullyGrown":"已成熟","keepGrowing":"每一段专注，都在生长","viewGarden":"看看小院","harvestFirst":"当前植物已成熟。请先收入小院，再开始新的专注。","dayNames":["日","一","二","三","四","五","六"],"custom":"自定义","customLabel":"专注时长","customHint":"输入 1–180 之间的整数分钟","customError":"请输入 1–180 之间的整数。","apply":"设定时长","shortBreak":"短休息","longBreak":"长休息","focusMode":"沉浸专注","exitFocus":"退出沉浸","daylight":"晴日","sunset":"暮色","sceneLabel":"窗外的光","timerHint":"专注一会儿，让小院长大一点。","restHint":"起身走走，喝一口水。","taskSuggestions":["阅读","学习","写作","工作"],"allPlants":"全部植物","available":"已解锁","blooming":"观花植物","foliage":"观叶植物","herbs":"香草植物","fruiting":"结果植物","preview":"查看成长","previewNote":"点选阶段，看看它未来的模样。","backSeeds":"返回种子图鉴","unlockRemaining":"再专注 {n} 分钟解锁","seedCount":"种植物，等你慢慢认识","gardenShelf":"你的时间，会开花。","gardenShelfNote":"每次专注，都让窗台多一点绿意。","catalogLink":"逛逛种子图鉴","discovered":"已解锁","liveSession":"计时仍在继续","returnTimer":"返回计时","elapsed":"本次已专注","startRest":"开始休息","growthPreview":"成长预览","specimen":"植物档案","availableHint":"随时可以开始培养","noPlants":"这里暂时没有植物","progressHint":"完成专注后，成长会记入植物。","skipMain":"跳到主要内容","stop":"停止","focusSanctuary":"这一刻，只做一件事。","liveGrowth":"你的专注，正在给它生长的力量。","livePaused":"时间停一停，植物也歇一歇。","liveRest":"让眼睛休息，让思绪透透气。","growingTogether":"和你一起，慢慢长大","sessionGrowth":"本次成长","sessionProgressNote":"停止时保留已完成的整分钟","chooseCompanion":"今天，和它一起专注","seedShelfTitle":"下一次，想种点什么？","seedShelfNote":"从一颗小种子，收藏认真过的日子。","sessionTask":"正在专注","sessionRest":"休息时光","sessionDuration":"本轮时长"},"showcase":["mint","daisy","cactus"]};
const { ui: t, plants, timing, brand } = content;
let state = freshState();
let storageMessage = '';
try { const raw = localStorage.getItem(STORAGE_KEY); if (raw) state = restore(raw, plants); } catch { storageMessage = t.storageReset; }
let page = 'focus';
let minutes = state.session?.mode === 'focus' ? state.session.duration / 60000 : timing.default;
let task = '';
let dialog = null;
let focusReturn = null;
let plantFilter = 'all';
let scene = 'daylight';
let customDuration = !timing.presets.includes(minutes);
const app = document.querySelector('#app');
const escape = value => String(value).replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]);
const id = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const plant = () => plants.find(item => item.id === state.selected);
const grown = () => state.progress[state.selected] || 0;
const isMature = () => grown() >= plant().stages.at(-1).at;
function save() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch { storageMessage = t.storageError; } }
function reconcile() {
  if (state.session?.status === 'running' && remaining(state.session, Date.now()) === 0) {
    const outcome = settle(state, Date.now(), plants); state = outcome.state; dialog = { type: 'result', ...outcome.result }; save(); return true;
  }
  return false;
}
function stats() {
  const today = state.records.filter(record => localDay(record.at) === localDay(Date.now()));
  return `<div class="stats"><div><span>${t.today}</span><strong>${today.reduce((sum, r) => sum + r.minutes, 0)}<small>${t.minutes}</small></strong></div><div><span>${t.sessions}</span><strong>${today.filter(r => r.complete).length}<small> / ${t.today.slice(0, 2)}</small></strong></div><div><span>${t.total}</span><strong>${state.total}<small>${t.minutes}</small></strong></div></div>`;
}
function focusPage() {
  const p = plant(); const stage = stageOf(p, grown()); const maturity = p.stages.at(-1).at;
  return `<div class="page-heading"><div><p class="eyebrow">${t.eyebrow}</p><h1>${t.focusTitle}</h1></div><span class="season">${icon('sun')} ${brand.tagline}</span></div>
  <section class="home-workbench ${scene}">
    <div class="workbench-header"><span>${icon('garden')}${t.chooseCompanion}</span><div class="scene-switch" role="group" aria-label="${t.sceneLabel}">${['daylight', 'sunset'].map(key => `<button data-action="scene" data-value="${key}" aria-pressed="${scene === key}" aria-label="${t[key]}">${icon(key === 'daylight' ? 'sun' : 'moon')}</button>`).join('')}</div></div>
    <div class="workbench-scene"><div class="home-clock"><p class="eyebrow">${t.nav[0]}</p><div id="timer" class="timer" role="timer" aria-label="${t.nav[0]}"></div><p>${t.timerHint}</p></div><div class="home-plant">${plantArt(p.id, stage, true)}</div></div>
    <div class="home-plant-summary"><div class="plant-caption"><h2>${p.name}<span>${p.stages[stage].name}</span></h2><p>${p.stages[stage].note}</p></div><button class="text-button" data-action="seeds">${t.newPlant} ↗</button></div>
    <div class="home-growth"><div class="home-growth-track" role="progressbar" aria-label="${t.stage}" aria-valuemin="0" aria-valuemax="${maturity}" aria-valuenow="${grown()}"><span style="width:${grown() / maturity * 100}%"></span></div><span>${grown()} / ${maturity}′</span><button class="text-button" data-action="detail" data-id="${p.id}">${t.growthPreview} ↗</button></div>
    <div class="home-settings"><div class="duration-options" role="group" aria-label="${t.customLabel}">${timing.presets.map(value => `<button class="duration ${minutes === value && !customDuration ? 'active' : ''}" aria-pressed="${minutes === value && !customDuration}" data-action="duration" data-value="${value}">${value} ${t.minutes}</button>`).join('')}<button class="duration ${customDuration ? 'active' : ''}" data-action="custom" aria-pressed="${customDuration}">${customDuration ? minutes + '′' : t.custom}</button></div>
    <label class="task-label" for="task">${t.taskLabel}</label><input id="task" maxlength="80" placeholder="${t.taskPlaceholder}" value="${escape(task)}"><div class="task-suggestions">${t.taskSuggestions.map((label, i) => `<button data-action="suggest" data-value="${i}">${label}</button>`).join('')}</div>
    <button class="primary" data-action="${isMature() ? 'collect' : 'start'}">${icon(isMature() ? 'garden' : 'play')}${isMature() ? t.collect : t.start}${icon('arrow')}</button><div class="rest-options"><button data-action="rest">${icon('sun')}${t.shortBreak} · ${timing.rest}′</button><span>·</span><button data-action="long-rest">${t.longBreak} · ${timing.longRest}′</button></div></div>
  </section>${stats()}
  <section class="garden-invitation"><div class="invitation-copy"><p class="eyebrow">${t.seedTitle}</p><h2>${t.seedShelfTitle}</h2><p>${t.seedShelfNote}</p></div><div class="invitation-art">${content.showcase.map(id => plantArt(id, 4)).join('')}</div><button class="text-button" data-action="seeds"><span>${t.catalogLink}</span>${icon('arrow')}</button></section>
  <div class="bottom-note"><span>${icon('garden')} ${t.keepGrowing}</span><span>${t.local}</span></div>`;
}
function sessionPage() {
  const session = state.session; const p = plants.find(item => item.id === session.plantId);
  const paused = session.status === 'paused'; const rest = session.mode === 'rest';
  return `<main id="main" class="focus-sanctuary ${scene} ${paused ? 'is-paused' : ''} ${rest ? 'is-rest' : ''}" tabindex="-1" aria-label="${rest ? t.sessionRest : t.nav[0]}">
    <div class="session-intro"><p class="eyebrow">${brand.name} / ${rest ? t.sessionRest : t.sessionTask}</p><h1>${rest ? t.resting : t.focusSanctuary}</h1><p class="session-task">${escape(session.task)}</p></div>
    <div class="session-world" aria-hidden="true"><div class="growth-halo"></div><div class="growth-motes"><i></i><i></i><i></i><i></i><i></i></div><div id="live-plant"></div><div class="soil-ripples"><i></i><i></i></div></div>
    <div class="session-readout"><p id="live-growth-note" class="session-status" role="status">${paused ? t.livePaused : rest ? t.liveRest : t.liveGrowth}</p><div id="timer" class="timer" role="timer" aria-label="${t.nav[0]}"></div><p class="session-duration">${t.sessionDuration} ${session.duration / 60000} ${t.minutes}<span>·</span>${p.name}<span id="live-stage"></span></p><div class="session-progress" role="progressbar" aria-label="${rest ? t.sessionRest : t.nav[0]}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><span id="session-progress-fill"></span></div><p class="session-earned" id="session-earned"></p></div>
    <div class="session-controls"><button class="primary" data-action="pause">${icon(paused ? 'play' : 'pause')}${paused ? t.resume : t.pause}</button><button class="stop-button" data-action="finish">${icon('stop')}${t.stop}</button></div>
    <p class="session-footnote">${rest ? t.restHint : t.sessionProgressNote}</p>${storageMessage ? `<p class="session-storage" role="alert">${storageMessage}</p>` : ''}
  </main>`;
}
function seedsMarkup() {
  const filters = [['all', t.allPlants], ['available', t.available], ...['fruiting', 'blooming', 'foliage', 'herbs'].map(key => [t[key], t[key]])];
  const visible = plants.filter(p => plantFilter === 'all' || (plantFilter === 'available' ? p.unlock <= state.total : p.kind === plantFilter));
  return `<div class="catalog-meta"><span>${plants.filter(p => p.unlock <= state.total).length} / ${plants.length} ${t.discovered}</span><span>${plants.length} ${t.seedCount}</span></div><div class="plant-filters" role="group" aria-label="${t.plantDetail}">${filters.map(([value,label]) => `<button data-action="filter" data-value="${value}" aria-pressed="${plantFilter === value}">${label}</button>`).join('')}</div><div class="seed-grid">${visible.map(p => {
    const locked = state.total < p.unlock;
    return `<article class="seed-card ${p.id === state.selected ? 'chosen' : ''} ${locked ? 'locked' : ''}"><button class="seed-art-button" data-action="detail" data-id="${p.id}" aria-label="${p.name} · ${t.preview}">${plantArt(p.id, 4)}<span>${t.preview} ↗</span></button><div class="seed-info"><span class="plant-kind">${p.kind} · ${p.stages.at(-1).at}′</span><h3>${p.name}</h3><p>${p.description}</p><button class="seed-status" data-action="select" data-id="${p.id}" ${locked || state.session ? 'disabled' : ''}>${locked ? icon('lock') + t.unlockRemaining.replace('{n}', p.unlock - state.total) : p.id === state.selected ? icon('check') + t.selected : t.select + ' ↗'}</button></div></article>`;
  }).join('') || `<p>${t.noPlants}</p>`}</div>`;
}
function gardenPage() {
  return `<div class="page-heading"><div><p class="eyebrow">${t.nav[1]}</p><h1>${t.gardenTitle}</h1><p class="subheading">${t.gardenSubtitle}</p></div><span class="garden-count">${state.collection.length}<small>${t.collection}</small></span></div><section class="collection">${state.collection.length ? state.collection.slice().reverse().map(item => { const p = plants.find(p => p.id === item.plantId); return `<article class="collected-plant">${plantArt(p.id, 4)}<h3>${p.name}</h3><p>${new Date(item.at).toLocaleDateString('zh-CN')} · ${item.minutes}′</p></article>`; }).join('') : `<div class="empty-garden">${plantArt(state.selected, 1)}<h2>${t.emptyGarden}</h2><p>${t.emptyGardenNote}</p><button class="text-button" data-action="focus">${t.start} ${icon('arrow')}</button></div>`}</section><div class="section-heading"><h2>${t.seedTitle}</h2><span>${t.plantDetail}</span></div>${seedsMarkup()}<p class="footnote">${t.seedIntro}</p>`;
}
function journalPage() {
  const days = Array.from({ length: 7 }, (_, i) => { const date = new Date(); date.setHours(12, 0, 0, 0); date.setDate(date.getDate() - 6 + i); return { label: t.dayNames[date.getDay()], value: state.records.filter(r => localDay(r.at) === localDay(date)).reduce((sum, r) => sum + r.minutes, 0) }; });
  const max = Math.max(25, ...days.map(d => d.value));
  return `<div class="page-heading"><div><p class="eyebrow">${t.nav[2]}</p><h1>${t.journalTitle}</h1></div></div>${stats()}<section class="week-panel"><h2>${t.week}</h2><div class="chart">${days.map((d, i) => `<div class="chart-column ${i === 6 ? 'today' : ''}"><span>${d.value}′</span><div class="bar-track"><div class="bar" style="height:${Math.max(2, d.value / max * 100)}%"></div></div><span>${d.label}</span></div>`).join('')}</div></section><div class="section-heading"><h2>${t.recent}</h2></div><div class="records">${state.records.length ? state.records.slice(-30).reverse().map(r => `<article class="record">${icon(r.complete ? 'check' : 'timer')}<div><strong>${escape(r.task || t.taskDefault)}</strong><p>${new Date(r.at).toLocaleString('zh-CN', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })} · ${r.complete ? t.complete : t.partial} · ${plants.find(p => p.id === r.plantId).name}</p></div><b>+${r.minutes}<small>${t.minuteShort}</small></b></article>`).join('') : `<p class="empty-records">${t.emptyRecords}</p>`}</div>`;
}
function modalMarkup() {
  if (!dialog) return '';
  let body;
  if (dialog.type === 'custom') body = `<div class="dialog-icon">${icon('timer')}</div><h2 id="dialog-title">${t.customLabel}</h2><p id="custom-hint">${t.customHint}</p><form id="duration-form" novalidate><label class="custom-input-label" for="custom-minutes">${t.minutes}</label><input id="custom-minutes" type="number" inputmode="numeric" min="${timing.min}" max="${timing.max}" step="1" value="${minutes}" aria-describedby="custom-hint custom-error"><p id="custom-error" class="form-error" role="alert"></p><button class="primary" type="submit">${t.apply}</button></form>`;
  else if (dialog.type === 'detail') {
    const p = plants.find(p => p.id === dialog.plantId); const index = dialog.stage; const locked = state.total < p.unlock;
    body = `<p class="eyebrow">${t.plantDetail} / ${p.kind}</p><h2 id="dialog-title">${p.name}</h2><p class="latin">${p.latin}</p><div class="detail-plant">${plantArt(p.id, index, true)}</div><div class="preview-stages" role="group" aria-label="${t.growthPreview}">${p.stages.map((stage,i) => `<button data-action="preview-stage" data-value="${i}" aria-pressed="${i === index}"><span>${stage.name}</span><small>${stage.at}′</small></button>`).join('')}</div><p>${p.stages[index].note}</p><p class="preview-note">${t.previewNote}</p><button class="primary" data-action="select" data-id="${p.id}" ${locked || state.session ? 'disabled' : ''}>${locked ? t.unlockRemaining.replace('{n}', p.unlock - state.total) : t.select}</button><button class="text-button" data-action="seeds">${t.backSeeds}</button>`;
  }
  else if (dialog.type === 'seeds') body = `<h2 id="dialog-title">${t.seedTitle}</h2><p>${t.replace}</p>${seedsMarkup()}<p class="footnote">${t.seedIntro}</p>`;
  else if (dialog.type === 'result') {
    const p = plants.find(p => p.id === dialog.plantId) || plant();
    body = `${dialog.rest ? `<div class="dialog-icon">${icon('sun')}</div>` : `<div class="result-plant">${plantArt(p.id, dialog.stage)}</div>`}<h2 id="dialog-title">${dialog.rest ? t.restDone : t.success}</h2>${dialog.rest ? '' : `<p class="reward">+${dialog.minutes}<span>${t.minutes} ${t.growth}</span></p><p>${p.name} · ${p.stages[dialog.stage].name}</p>`}<button class="primary" data-action="${dialog.rest ? 'close' : 'rest'}">${dialog.rest ? t.again : t.rest}</button><button class="text-button" data-action="garden">${t.viewGarden}</button>`;
  }
  return `<div class="modal-backdrop"><section class="modal ${dialog.type === 'seeds' ? 'wide' : ''}" role="dialog" aria-modal="true" aria-labelledby="dialog-title"><button class="close" data-action="close" aria-label="${t.close}">×</button>${body}</section></div>`;
}
function returnFocus() {
  const target = [...document.querySelectorAll(`[data-action="${focusReturn || 'start'}"]`)].find(element => !element.disabled && element.getClientRects().length);
  const fallback = ['[data-action=start]', '[data-action=collect]', 'nav [aria-current]'].map(selector => document.querySelector(selector)).find(element => element && !element.disabled && element.getClientRects().length);
  (target || fallback)?.focus();
}
function render() {
  const active = !!state.session;
  app.innerHTML = active ? sessionPage() : `<a class="skip-link" href="#main">${t.skipMain}</a><header class="site-header"><a class="brand" href="#" data-action="focus">${icon('garden')}<span>${brand.name}<small>${brand.en}</small></span></a><nav aria-label="${brand.name}">${['focus', 'garden', 'journal'].map((key, i) => `<button data-action="${key}" class="nav-button ${page === key ? 'active' : ''}" ${page === key ? 'aria-current="page"' : ''}>${icon(['timer', 'garden', 'book'][i])}<span>${t.nav[i]}</span></button>`).join('')}</nav><span class="header-note">${t.saved}</span></header><main id="main" tabindex="-1">${storageMessage ? `<p class="storage-warning" role="alert">${storageMessage}</p>` : ''}${page === 'focus' ? focusPage() : page === 'garden' ? gardenPage() : journalPage()}</main><footer>${brand.en}<span>${t.localDetail}</span></footer>${modalMarkup()}`;
  [...app.children].filter(element => !element.classList.contains('modal-backdrop')).forEach(element => { element.inert = !!dialog; });
  document.body.classList.toggle('modal-open', !!dialog);
  document.body.classList.toggle('session-active', active);
  updateTimer();
  if (dialog) document.querySelector('.modal button:not(:disabled)')?.focus();
}
function updateTimer() {
  const target = document.querySelector('#timer');
  const seconds = Math.ceil(state.session ? remaining(state.session, Date.now()) / 1000 : minutes * 60);
  const clock = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
  if (target) target.textContent = clock;
  if (state.session) {
    const session = state.session; const p = plants.find(item => item.id === session.plantId);
    const elapsed = session.duration - remaining(session, Date.now());
    const earned = session.mode === 'rest' ? 0 : Math.floor(elapsed / 60000);
    const progress = Math.min(p.stages.at(-1).at, (state.progress[p.id] || 0) + earned);
    const stage = stageOf(p, progress); const art = document.querySelector('#live-plant');
    if (art && art.dataset.stage !== String(stage)) {
      art.innerHTML = plantArt(p.id, stage); art.dataset.stage = String(stage);
    }
    document.querySelector('#live-stage').textContent = ' · ' + p.stages[stage].name;
    document.querySelector('#session-earned').textContent = session.mode === 'rest' ? t.growingTogether : `${t.sessionGrowth} +${earned} ${t.minutes}`;
    const percent = Math.min(100, elapsed / session.duration * 100);
    document.querySelector('#session-progress-fill').style.transform = `scaleX(${percent / 100})`;
    document.querySelector('.session-progress').setAttribute('aria-valuenow', String(Math.floor(percent)));
  }
  document.title = state.session ? `${clock} · ${brand.name}` : brand.name;
}
app.addEventListener('input', event => { if (event.target.id === 'task') task = event.target.value; });
app.addEventListener('click', event => {
  const button = event.target.closest('[data-action]'); if (!button || button.disabled) return;
  event.preventDefault();
  if (reconcile()) { render(); return; }
  const action = button.dataset.action;
  if (state.session && !['pause', 'finish'].includes(action)) return;
  if (['focus', 'garden', 'journal'].includes(action)) { page = action; dialog = null; }
  else if (action === 'duration') { minutes = Number(button.dataset.value); customDuration = false; }
  else if (action === 'custom') { focusReturn = action; dialog = { type: 'custom' }; }
  else if (action === 'suggest') task = t.taskSuggestions[Number(button.dataset.value)];
  else if (action === 'scene') scene = button.dataset.value;
  else if (action === 'filter') plantFilter = button.dataset.value;
  else if (action === 'detail') { focusReturn = action; dialog = { type: 'detail', plantId: button.dataset.id, stage: 4 }; }
  else if (action === 'preview-stage') dialog.stage = Number(button.dataset.value);
  else if (action === 'start') { if (isMature()) return; state = startSession(state, { id: id(), minutes, task: task.trim() || t.taskDefault, now: Date.now() }); }
  else if (action === 'pause') state = togglePause(state, Date.now());
  else if (action === 'finish') { const outcome = settle(state, Date.now(), plants); state = outcome.state; page = 'focus'; dialog = { type: 'result', ...outcome.result }; }
  else if (action === 'seeds') { focusReturn = action; dialog = { type: 'seeds' }; }
  else if (action === 'close') dialog = null;
  else if (action === 'rest' || action === 'long-rest') { dialog = null; page = 'focus'; state = startSession(state, { id: id(), minutes: action === 'long-rest' ? timing.longRest : timing.rest, task: t.resting, mode: 'rest', now: Date.now() }); }
  else if (action === 'collect') { state = collect(state, plants, Date.now(), id()); dialog = { type: 'seeds' }; }
  else if (action === 'select') { const p = plants.find(p => p.id === button.dataset.id); if (!p || p.unlock > state.total || state.session) return; state = { ...state, selected: p.id }; page = 'focus'; dialog = null; }
  save(); render();
  if (['focus', 'garden', 'journal', 'select', 'start', 'rest', 'long-rest'].includes(action)) {
    document.querySelector('#main').focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }
  if (['filter', 'preview-stage', 'scene', 'duration', 'suggest', 'pause'].includes(action)) [...(dialog ? document.querySelector('.modal') : app).querySelectorAll('[data-action]')].find(el => el.dataset.action === action && el.dataset.value === button.dataset.value)?.focus();
  if (['start', 'rest', 'long-rest'].includes(action)) document.querySelector('[data-action=pause]')?.focus({ preventScroll: true });
  if (action === 'custom') document.querySelector('#custom-minutes')?.focus();
  if (action === 'close') returnFocus();
});
app.addEventListener('submit', event => {
  if (event.target.id !== 'duration-form') return;
  event.preventDefault();
  const input = document.querySelector('#custom-minutes'); const value = Number(input.value);
  if (!Number.isInteger(value) || value < timing.min || value > timing.max) { input.setAttribute('aria-invalid', 'true'); document.querySelector('#custom-error').textContent = t.customError; input.focus(); return; }
  minutes = value; customDuration = true; dialog = null; render(); document.querySelector('[data-action=custom]')?.focus();
});
document.addEventListener('keydown', event => {
  if (state.session) {
    if (event.key === 'Tab') {
      const first = document.querySelector('[data-action=pause]'); const last = document.querySelector('[data-action=finish]');
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
    return;
  }
  if (!dialog) return;
  if (event.key === 'Escape') { dialog = null; render(); returnFocus(); }
  if (event.key === 'Tab') {
    const buttons = [...document.querySelectorAll('.modal button:not(:disabled), .modal input:not(:disabled)')];
    const first = buttons[0]; const last = buttons.at(-1);
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});
window.addEventListener('storage', event => {
  if (event.key !== STORAGE_KEY) return;
  try { state = event.newValue ? restore(event.newValue, plants) : freshState(); dialog = null; reconcile(); render(); } catch { storageMessage = t.storageReset; render(); }
});
document.addEventListener('visibilitychange', () => { if (reconcile()) render(); else updateTimer(); });
setInterval(() => { if (reconcile()) render(); else updateTimer(); }, 250);
reconcile(); render();

})();

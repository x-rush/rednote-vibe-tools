"use strict";
(function () {
    var _a, _b;
    const probe = document.createElement('div');
    probe.style.cssText = 'position:absolute;visibility:hidden;display:flex;flex-direction:column;row-gap:1px';
    probe.appendChild(document.createElement('div'));
    probe.appendChild(document.createElement('div'));
    document.body.appendChild(probe);
    if (probe.scrollHeight !== 1)
        document.documentElement.classList.add('no-flex-gap');
    probe.remove();
    if (!Array.prototype.findLastIndex)
        Array.prototype.findLastIndex = function (fn) { for (let i = this.length - 1; i >= 0; i--)
            if (fn(this[i], i, this))
                return i; return -1; };
    if (!Array.prototype.at)
        Array.prototype.at = function (i) { return this[i < 0 ? this.length + i : i]; };
    class RhythmEngine {
        constructor(chart, rules) { this.rules = rules; this.notes = chart.map(n => (Object.assign(Object.assign({}, n), { status: 'pending', earned: 0, last: null, quality: 0 }))); this.score = 0; this.combo = 0; this.maxCombo = 0; this.counts = { perfect: 0, good: 0, miss: 0 }; this.events = []; this.time = 0; this.doubleAwarded = new Set(); this.tapChords = new Set(); }
        emit(type, n, extra = {}) { this.events.push(Object.assign({ type, lane: n === null || n === void 0 ? void 0 : n.lane, id: n === null || n === void 0 ? void 0 : n.id }, extra)); }
        hit(lane, t) {
            const suspended = this.notes.find(n => n.lane === lane && n.status === 'suspended' && t <= n.resumeDeadline);
            if (suspended) {
                suspended.status = 'holding';
                suspended.last = Math.max(t, suspended.time);
                this.emit('resume', suspended, { hold: true });
                return suspended;
            }
            if (this.notes.some(n => n.lane === lane && n.status === 'holding'))
                return null;
            const n = this.notes.find(n => n.lane === lane && n.status === 'pending' && Math.abs(n.time - t) <= this.rules.good);
            if (!n)
                return null;
            const perfect = Math.abs(n.time - t) <= this.rules.perfect;
            n.quality = perfect ? 1 : .6;
            n.earned = perfect ? 100 : 60;
            this.score += n.earned;
            this.counts[perfect ? 'perfect' : 'good']++;
            this.combo++;
            this.maxCombo = Math.max(this.combo, this.maxCombo);
            n.status = n.duration ? 'holding' : 'done';
            n.last = Math.max(t, n.time);
            this.emit(perfect ? 'perfect' : 'good', n, { hold: !!n.duration });
            if (!n.duration) {
                const key = n.time.toFixed(4), group = this.notes.filter(p => !p.duration && Math.abs(p.time - n.time) < .001);
                if (group.length > 1 && group.every(p => p.status === 'done') && !this.tapChords.has(key)) {
                    this.tapChords.add(key);
                    this.emit('double', n, { tap: true });
                }
            }
            return n;
        }
        accrue(n, t) { const end = Math.min(t, n.time + n.duration); if (end > n.last) {
            const v = (end - n.last) * this.rules.holdPointsPerSecond;
            this.score += v;
            n.earned += v;
            n.last = end;
        } }
        release(lane, t) { for (const n of this.notes.filter(n => n.lane === lane && n.status === 'holding')) {
            this.accrue(n, t);
            if (t >= n.time + n.duration)
                this.finish(n);
            else {
                n.status = 'broken';
                this.combo = 0;
                this.emit('break', n);
            }
        } }
        finish(n) {
            n.status = 'done';
            n.earned += this.rules.holdBonus;
            this.score += this.rules.holdBonus;
            this.emit('complete', n);
            const pair = this.notes.find(p => p.id !== n.id && p.duration && Math.abs(p.time - n.time) < .001 && p.status === 'done');
            const key = n.time.toFixed(4);
            if (pair && !this.doubleAwarded.has(key)) {
                this.doubleAwarded.add(key);
                this.score += this.rules.doubleBonus;
                this.emit('double', n);
            }
        }
        update(t) { this.time = t; for (const n of this.notes) {
            if (n.status === 'suspended' && t > n.resumeDeadline) {
                n.status = 'broken';
                this.combo = 0;
                this.emit('break', n);
            }
            else if (n.status === 'holding') {
                this.accrue(n, t);
                if (t >= n.time + n.duration)
                    this.finish(n);
            }
            else if (n.status === 'pending' && t > n.time + this.rules.good) {
                n.status = 'miss';
                this.counts.miss++;
                this.combo = 0;
                this.emit('miss', n);
            }
        } }
        suspend(t) { for (const n of this.notes)
            if (n.status === 'holding') {
                this.accrue(n, t);
                if (t >= n.time + n.duration)
                    this.finish(n);
                else
                    n.status = 'suspended';
            } }
        drain() { return this.events.splice(0); }
        get maxScore() { let total = this.notes.reduce((s, n) => s + 100 + (n.duration ? n.duration * this.rules.holdPointsPerSecond + this.rules.holdBonus : 0), 0); const seen = new Set(), awarded = new Set(); for (const n of this.notes.filter(n => n.duration)) {
            const key = n.time.toFixed(4);
            if (seen.has(key) && !awarded.has(key)) {
                total += this.rules.doubleBonus;
                awarded.add(key);
            }
            else
                seen.add(key);
        } return total; }
        get accuracy() { return Math.min(100, this.score / this.maxScore * 100) || 0; }
        phraseSuccess(start, end) { const ns = this.notes.filter(n => n.time >= start && n.time < end); return ns.length > 0 && ns.filter(n => n.status === 'done').length / ns.length >= .75; }
        phraseResolved(start, end) { return this.notes.filter(n => n.time >= start && n.time < end).every(n => ['done', 'miss', 'broken'].includes(n.status)); }
    }
    function validateChart(notes, duration) {
        const errors = [];
        const ids = new Set();
        for (const n of notes) {
            if (ids.has(n.id))
                errors.push('duplicate id');
            ids.add(n.id);
            if (!Number.isFinite(n.time) || n.time < 0 || n.time + n.duration > duration)
                errors.push('invalid time');
            if (!Number.isInteger(n.lane) || n.lane < 0 || n.lane > 3 || n.duration < 0)
                errors.push('invalid lane/duration');
        }
        for (let lane = 0; lane < 4; lane++) {
            const ns = notes.filter(n => n.lane === lane).sort((a, b) => a.time - b.time);
            for (let i = 1; i < ns.length; i++) {
                const prev = ns[i - 1], next = ns[i], gap = next.time - prev.time;
                const pair = !prev.duration && !next.duration && gap >= .12 - 1e-6 &&
                    (!ns[i - 2] || prev.time - ns[i - 2].time - ns[i - 2].duration >= .3 - 1e-6) &&
                    (!ns[i + 1] || ns[i + 1].time - next.time >= .3 - 1e-6);
                if (next.time < prev.time + prev.duration + .18 - 1e-6 && !pair)
                    errors.push('overlapping lane');
            }
        }
        return errors;
    }
    class StageTimeline {
        constructor(phrases, dwell) { this.phrases = phrases; this.dwell = dwell; this.current = -1; this.releaseAt = 0; this.settled = new Set(); this.frozen = 0; }
        update(engine, now, judge, allowSettlement = true) {
            let desired = 0;
            for (let i = 0; i < this.phrases.length; i++)
                if (this.phrases[i].start <= now)
                    desired = i;
            let entered = null;
            const results = [];
            if (this.current < 0) {
                this.current = desired;
                entered = desired;
            }
            if (allowSettlement) {
                for (let i = 0; i < this.phrases.length; i++) {
                    const p = this.phrases[i];
                    if (judge < p.end || this.settled.has(i) || !engine.phraseResolved(p.start, p.end))
                        continue;
                    const success = engine.phraseSuccess(p.start, p.end);
                    this.settled.add(i);
                    if (success)
                        this.frozen++;
                    const visible = i === this.current;
                    results.push({ index: i, success, visible });
                    if (visible)
                        this.releaseAt = now + this.dwell;
                }
                if (desired > this.current && this.settled.has(this.current) && now >= this.releaseAt) {
                    this.current = desired;
                    entered = desired;
                }
            }
            return { entered, results };
        }
    }
    function outputTime(context, eventTime = performance.now(), now = performance.now()) {
        var _a;
        const at = Number.isFinite(eventTime) && Math.abs(eventTime - now) < 1000 ? eventTime : now;
        try {
            const stamp = (_a = context.getOutputTimestamp) === null || _a === void 0 ? void 0 : _a.call(context);
            if (stamp && stamp.contextTime > 0 && stamp.performanceTime > 0 && Math.abs(now - stamp.performanceTime) < 1000) {
                return Math.max(0, Math.min(context.currentTime, stamp.contextTime + (at - stamp.performanceTime) / 1000));
            }
        }
        catch (_b) { }
        const latency = Math.min(.5, Math.max(0, context.baseLatency || 0) + Math.max(0, context.outputLatency || 0));
        return Math.max(0, context.currentTime - latency + (at - now) / 1000);
    }
    function medianOffset(samples) {
        if (samples.length < 8)
            return null;
        const sorted = samples.filter(Number.isFinite).sort((a, b) => a - b);
        if (sorted.length < 8)
            return null;
        const middle = sorted.slice(2, -2);
        if (middle.at(-1) - middle[0] > 100)
            return null;
        const value = Math.round((sorted[Math.floor((sorted.length - 1) / 2)] + sorted[Math.ceil((sorted.length - 1) / 2)]) / 10) * 5;
        return Math.abs(value) <= 250 ? value : null;
    }
    const C = { "title": "武林外传：同福客栈风波再起", "titleParts": ["同福客栈", "风波再起"], "subtitle": "一曲好久不见，再闯同福江湖", "eyebrow": "武林外传 · 二十周年同人小游戏", "brand": "武林外传", "anniversary": "2006 — 2026", "seal": "同福", "yearStamp": "廿", "yearLabel": "周年", "heroCaption": "四指入拍 · 一曲定身", "recordLabel": "律", "laneLabel": "点穴键位", "displayDuration": "1:39", "restSeal": "歇", "resultSeals": ["定", "定", "侠", "宗"], "track": { "title": "好久不见", "artist": "李小龙", "version": "电视剧片头 · 完整版", "duration": 98.10408163265306, "bpm": 120, "beatOffset": 0.78, "chartStatus": "修订11：取消换人空窗，补齐Verse连接；短蓄力与喊声双击。音乐时序仍需实听验收。", "chartRevision": 11, "audioSha256": "174e3f8828dabe527c1ed96990d2c3f955871533848cb71b6ddbbba361a67ad2" }, "art": { "background": "art/inn.webp" }, "cast": [{ "name": "李大嘴", "role": "同福大厨", "line": "包子还没吃，先接你一招。", "pos": 0, "art": "art/dazui-final.webp", "homeArt": "art/dazui-cutout.webp" }, { "name": "吕秀才", "role": "关中大侠", "line": "子曰，出招也得讲节奏。", "pos": 1, "art": "art/xiucai-final.webp", "homeArt": "art/xiucai-cutout.webp" }, { "name": "郭芙蓉", "role": "芙蓉女侠", "line": "来！看看谁的手更快。", "pos": 2, "art": "art/furong-final.webp", "homeArt": "art/furong-cutout.webp" }, { "name": "佟湘玉", "role": "同福掌柜", "line": "客官，手下留点情。", "pos": 3, "art": "art/xiangyu-final.webp", "homeArt": "art/xiangyu-cutout.webp" }], "lanes": [{ "label": "左腰", "key": "D", "color": "#efab67", "target": [0.38, 0.58] }, { "label": "左肩", "key": "F", "color": "#f4ce83", "target": [0.36, 0.32] }, { "label": "右肩", "key": "J", "color": "#6bcfbe", "target": [0.65, 0.32] }, { "label": "右腰", "key": "K", "color": "#71adcb", "target": [0.67, 0.58] }], "rules": { "perfect": 0.085, "good": 0.155, "travel": 1.75, "holdPointsPerSecond": 50, "holdBonus": 50, "doubleBonus": 100 }, "phrases": [{ "start": 0, "end": 7.905, "cast": 0, "title": "前奏入拍" }, { "start": 7.905, "end": 15.9118, "cast": 1, "title": "前奏入拍" }, { "start": 15.9118, "end": 23.0922, "cast": 2, "title": "前奏入拍" }, { "start": 23.0922, "end": 30.4206, "cast": 3, "title": "兄弟相逢" }, { "start": 30.4206, "end": 38.78, "cast": 0, "title": "兄弟相逢" }, { "start": 38.78, "end": 47.6764, "cast": 1, "title": "江湖说唱" }, { "start": 47.6764, "end": 56.0474, "cast": 2, "title": "江湖说唱" }, { "start": 56.0474, "end": 63.3109, "cast": 3, "title": "江湖说唱" }, { "start": 63.3109, "end": 72.6696, "cast": 0, "title": "江湖说唱" }, { "start": 72.6696, "end": 80.6514, "cast": 1, "title": "再聚同福" }, { "start": 80.6514, "end": 87.0768, "cast": 2, "title": "再聚同福" }, { "start": 87.0768, "end": 98.10408163265306, "cast": 3, "title": "再聚同福" }], "notes": [{ "id": "v3-0", "time": 0.7765, "lane": 0, "duration": 0, "source": "drum" }, { "id": "v3-1", "time": 1.5348, "lane": 2, "duration": 0, "source": "drum" }, { "id": "v3-2", "time": 2.2681, "lane": 1, "duration": 0, "source": "drum" }, { "id": "v3-3", "time": 2.7919, "lane": 3, "duration": 0, "source": "drum" }, { "id": "v3-4", "time": 3.5302, "lane": 0, "duration": 0, "source": "drum" }, { "id": "v3-5", "time": 4.2686, "lane": 2, "duration": 0, "source": "drum" }, { "id": "v3-6", "time": 4.7824, "lane": 1, "duration": 0, "source": "drum" }, { "id": "v3-7", "time": 5.2414, "lane": 3, "duration": 0, "source": "drum" }, { "id": "v3-8", "time": 6.274, "lane": 0, "duration": 0, "source": "drum" }, { "id": "v3-9", "time": 6.7829, "lane": 2, "duration": 0, "source": "drum" }, { "id": "v3-10", "time": 7.5162, "lane": 1, "duration": 0, "source": "drum" }, { "id": "v3-11", "time": 8.025, "lane": 3, "duration": 0, "source": "drum" }, { "id": "v3-12", "time": 8.5239, "lane": 0, "duration": 0, "source": "drum" }, { "id": "v3-13", "time": 9.5316, "lane": 2, "duration": 0, "source": "drum" }, { "id": "v3-14", "time": 10.2749, "lane": 1, "duration": 0, "source": "drum" }, { "id": "v3-15", "time": 10.7838, "lane": 3, "duration": 0, "source": "drum" }, { "id": "v3-16", "time": 11.5321, "lane": 0, "duration": 0, "source": "drum" }, { "id": "v3-17", "time": 12.2754, "lane": 2, "duration": 0, "source": "drum" }, { "id": "v3-18", "time": 12.7842, "lane": 1, "duration": 0, "source": "drum" }, { "id": "v3-19", "time": 13.5225, "lane": 3, "duration": 0, "source": "drum" }, { "id": "v3-20", "time": 14.7797, "lane": 0, "duration": 0, "source": "drum" }, { "id": "v3-21", "time": 15.528, "lane": 2, "duration": 0, "source": "drum" }, { "id": "v3-22", "time": 16.0318, "lane": 1, "duration": 0, "source": "drum" }, { "id": "v3-23", "time": 16.8716, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-24", "time": 17.5202, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-25", "time": 17.7896, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-26", "time": 18.5229, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-27", "time": 19.0367, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-28", "time": 19.4857, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-29", "time": 19.7601, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-30", "time": 20.0095, "lane": 1, "duration": 0.3905, "source": "sustain" }, { "id": "v3-31", "time": 20.5084, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-32", "time": 20.7778, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-33", "time": 21.5161, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-34", "time": 21.7406, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-35", "time": 22.5238, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-36", "time": 23.2122, "lane": 1, "duration": 0.4078, "source": "sustain" }, { "id": "v3-37", "time": 23.2122, "lane": 2, "duration": 0.4078, "source": "sustain" }, { "id": "v3-38", "time": 23.741, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-39", "time": 24.0204, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-40", "time": 24.2499, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-41", "time": 24.5392, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-42", "time": 24.8136, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-43", "time": 25.5569, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-44", "time": 25.8113, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-45", "time": 26.5297, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-46", "time": 26.7741, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-47", "time": 27.0186, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-48", "time": 27.268, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-49", "time": 27.4825, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-50", "time": 27.7419, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-51", "time": 28.0063, "lane": 1, "duration": 0.3737, "source": "sustain" }, { "id": "v3-52", "time": 28.4952, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-53", "time": 28.7496, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-54", "time": 29.5029, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-55", "time": 29.7424, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-56", "time": 30.5406, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-57", "time": 31.0145, "lane": 1, "duration": 0.6055, "source": "sustain" }, { "id": "v3-58", "time": 31.0145, "lane": 2, "duration": 0.6055, "source": "sustain" }, { "id": "v3-59", "time": 31.7229, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-60", "time": 31.9973, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-61", "time": 32.2118, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-62", "time": 32.5061, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v8-smile-0", "time": 32.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-smile-1", "time": 32.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-smile-2", "time": 33.045, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-smile-3", "time": 33.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-smile-4", "time": 33.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-response-a-0", "time": 33.795, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-response-a-1", "time": 33.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-response-a-2", "time": 34.045, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-response-a-3", "time": 34.17, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-response-a-4", "time": 34.42, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-cry-0", "time": 34.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-cry-1", "time": 34.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-cry-2", "time": 35.045, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-cry-3", "time": 35.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-cry-4", "time": 35.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-response-b-0", "time": 35.795, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "response-b" }, { "id": "v8-response-b-1", "time": 35.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-b" }, { "id": "v8-response-b-2", "time": 36.045, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "response-b" }, { "id": "v8-response-b-3", "time": 36.17, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-b" }, { "id": "v8-response-b-4", "time": 36.42, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-b" }, { "id": "v8-lead-qing-0", "time": 36.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "lead-qing" }, { "id": "v8-lead-qing-1", "time": 36.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "lead-qing" }, { "id": "v8-lead-qing-2", "time": 37.045, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "lead-qing" }, { "id": "v8-lead-qing-3", "time": 37.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "lead-qing" }, { "id": "v8-lead-qing-4", "time": 37.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "lead-qing" }, { "id": "v8-qing-0", "time": 37.67, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "qing", "label": "清" }, { "id": "v8-qing-1", "time": 37.92, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "qing", "label": "清" }, { "id": "v8-qing-2", "time": 38.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "qing", "label": "楚" }, { "id": "v8-qing-3", "time": 38.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "qing", "label": "楚" }, { "id": "v8-road-0", "time": 38.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "road" }, { "id": "v8-road-1", "time": 38.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "road" }, { "id": "v8-road-2", "time": 39.17, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "road" }, { "id": "v8-road-3", "time": 39.42, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "road" }, { "id": "v8-road-4", "time": 39.67, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "road" }, { "id": "v11-fill-0", "time": 39.92, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "road" }, { "id": "v8-road-5", "time": 40.17, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "road" }, { "id": "v8-lead-greeting-0", "time": 40.545, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "lead-greeting" }, { "id": "v8-greeting-0", "time": 40.67, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "greeting", "label": "好" }, { "id": "v8-greeting-1", "time": 40.92, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "greeting", "label": "久" }, { "id": "v8-greeting-2", "time": 41.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "greeting", "label": "不" }, { "id": "v8-greeting-3", "time": 41.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "greeting", "label": "见" }, { "id": "v8-where-0", "time": 41.67, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "where", "label": "你" }, { "id": "v8-where-1", "time": 41.92, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "where", "label": "去" }, { "id": "v8-where-2", "time": 42.17, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "where", "label": "何" }, { "id": "v8-where-3", "time": 42.42, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "where", "label": "处" }, { "id": "v8-reply-0", "time": 42.795, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "reply" }, { "id": "v8-reply-1", "time": 42.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "reply" }, { "id": "v8-reply-2", "time": 43.17, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "reply" }, { "id": "v8-reply-3", "time": 43.42, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "reply" }, { "id": "v8-jianghu-0", "time": 43.795, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "jianghu" }, { "id": "v8-jianghu-1", "time": 44.045, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "jianghu" }, { "id": "v8-jianghu-2", "time": 44.17, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "jianghu" }, { "id": "v8-jianghu-3", "time": 44.42, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "jianghu" }, { "id": "v8-enyuan-0", "time": 44.67, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "enyuan", "label": "恩" }, { "id": "v8-enyuan-1", "time": 44.92, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "enyuan", "label": "恩" }, { "id": "v8-enyuan-2", "time": 45.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "enyuan", "label": "怨" }, { "id": "v8-enyuan-3", "time": 45.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "enyuan", "label": "怨" }, { "id": "v8-recognition-0", "time": 45.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "recognition" }, { "id": "v8-recognition-1", "time": 45.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "recognition" }, { "id": "v8-recognition-2", "time": 46.045, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "recognition" }, { "id": "v8-recognition-3", "time": 46.295, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "recognition" }, { "id": "v8-recognition-4", "time": 46.545, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "recognition" }, { "id": "v8-arrival-0", "time": 46.795, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "arrival" }, { "id": "v8-arrival-1", "time": 47.17, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "arrival" }, { "id": "v11-fill-1", "time": 47.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "arrival" }, { "id": "v11-fill-2", "time": 47.67, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "arrival" }, { "id": "v8-call-lai-0", "time": 47.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "call-lai" }, { "id": "v8-call-lai-1", "time": 48.045, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "call-lai" }, { "id": "v8-call-lai-2", "time": 48.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "call-lai" }, { "id": "v4-rap-9-2", "time": 48.52, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v4-rap-9-3", "time": 48.76, "lane": 3, "duration": 0.32, "source": "vocal" }, { "id": "v8-call-shuo-0", "time": 49.295, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "call-shuo" }, { "id": "v8-call-shuo-1", "time": 49.67, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "call-shuo" }, { "id": "v8-call-shuo-2", "time": 49.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "call-shuo" }, { "id": "v8-call-shuo-3", "time": 50.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "call-shuo" }, { "id": "v5-callout-shuo", "duration": 0, "source": "vocal", "time": 50.53, "lane": 1 }, { "id": "v4-rap-10-3", "time": 50.76, "lane": 3, "duration": 0.32, "source": "vocal" }, { "id": "v8-hardship-0", "time": 51.295, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "hardship" }, { "id": "v8-hardship-1", "time": 51.67, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "hardship" }, { "id": "v8-hardship-2", "time": 51.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "hardship" }, { "id": "v8-hardship-3", "time": 52.17, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "hardship" }, { "id": "v8-hardship-4", "time": 52.545, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "hardship" }, { "id": "v8-confidant-0", "time": 52.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "confidant" }, { "id": "v8-confidant-1", "time": 53.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "confidant" }, { "id": "v8-confidant-2", "time": 53.42, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "confidant" }, { "id": "v8-confidant-3", "time": 53.67, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "confidant" }, { "id": "v11-fill-3", "time": 53.92, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "confidant" }, { "id": "v11-fill-4", "time": 54.17, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "confidant" }, { "id": "v8-affection-0", "time": 54.295, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "affection" }, { "id": "v8-affection-1", "time": 54.42, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "affection" }, { "id": "v8-affection-2", "time": 54.67, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "affection" }, { "id": "v8-affection-3", "time": 54.92, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "affection" }, { "id": "v8-affection-4", "time": 55.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "affection" }, { "id": "v8-affection-5", "time": 55.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "affection" }, { "id": "v11-fill-5", "time": 55.67, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "affection" }, { "id": "v11-fill-6", "time": 55.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "affection" }, { "id": "v8-attachment-0", "time": 56.17, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "attachment" }, { "id": "v8-attachment-1", "time": 56.42, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "attachment" }, { "id": "v8-loneliness-0", "time": 56.795, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "loneliness" }, { "id": "v8-loneliness-1", "time": 56.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "loneliness" }, { "id": "v8-loneliness-2", "time": 57.17, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "loneliness" }, { "id": "v8-loneliness-3", "time": 57.42, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "loneliness" }, { "id": "v11-fill-7", "time": 57.67, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "loneliness" }, { "id": "v8-loneliness-4", "time": 57.92, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "loneliness" }, { "id": "v8-loneliness-5", "time": 58.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "loneliness" }, { "id": "v8-loneliness-6", "time": 58.42, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "loneliness" }, { "id": "v8-coming-going-0", "time": 58.67, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "coming-going" }, { "id": "v8-coming-going-1", "time": 58.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "coming-going" }, { "id": "v8-coming-going-2", "time": 59.17, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "coming-going" }, { "id": "v8-coming-going-3", "time": 59.42, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "coming-going" }, { "id": "v8-question-0", "time": 59.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "question" }, { "id": "v8-question-1", "time": 59.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "question" }, { "id": "v8-question-2", "time": 60.17, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "question" }, { "id": "v8-question-3", "time": 60.42, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "question" }, { "id": "v8-smile-again-0", "time": 60.67, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "smile-again" }, { "id": "v8-smile-again-1", "time": 60.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "smile-again" }, { "id": "v8-smile-again-2", "time": 61.17, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "smile-again" }, { "id": "v8-joy-0", "time": 61.295, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "joy" }, { "id": "v8-joy-1", "time": 61.42, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "joy" }, { "id": "v8-joy-2", "time": 61.67, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "joy" }, { "id": "v8-joy-3", "time": 61.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "joy" }, { "id": "v8-joy-4", "time": 62.17, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "joy" }, { "id": "v8-joy-5", "time": 62.42, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "joy" }, { "id": "v11-toast-0", "time": 62.795, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "toast-pickup" }, { "id": "v11-toast-1", "time": 62.92, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "toast-pickup" }, { "id": "v11-toast-2", "time": 63.17, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "toast-pickup" }, { "id": "v8-toast-0", "time": 63.42, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "toast" }, { "id": "v8-toast-1", "time": 63.795, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "toast" }, { "id": "v8-toast-2", "time": 64.045, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "toast" }, { "id": "v8-toast-3", "time": 64.295, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "toast" }, { "id": "v8-toast-4", "time": 64.545, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "toast" }, { "id": "v3-146", "time": 64.7877, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v11-chord-v3-146", "time": 64.7877, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-147", "time": 65.546, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-148", "time": 65.8304, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-149", "time": 68.7787, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v11-chord-v3-149", "time": 68.7787, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-150", "time": 69.532, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-151", "time": 69.8163, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-152", "time": 72.7896, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-153", "time": 73.5229, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-154", "time": 73.8372, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-155", "time": 74.5206, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-156", "time": 75.0394, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-157", "time": 75.4884, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-158", "time": 75.7578, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-159", "time": 76.0072, "lane": 2, "duration": 0.3928, "source": "sustain" }, { "id": "v3-160", "time": 76.5111, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-161", "time": 76.7805, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-162", "time": 77.5188, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-163", "time": 77.7433, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-164", "time": 78.5415, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-165", "time": 78.776, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-166", "time": 79.215, "lane": 1, "duration": 0.405, "source": "sustain" }, { "id": "v3-167", "time": 79.215, "lane": 2, "duration": 0.405, "source": "sustain" }, { "id": "v3-168", "time": 79.7438, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-169", "time": 80.0181, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-170", "time": 80.2526, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-171", "time": 80.7714, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-172", "time": 81.4948, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-173", "time": 81.7791, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-174", "time": 82.4975, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-175", "time": 82.7719, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-176", "time": 83.0213, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-177", "time": 83.2707, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-178", "time": 83.4852, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-179", "time": 83.7447, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-180", "time": 84.0041, "lane": 2, "duration": 0.3559, "source": "sustain" }, { "id": "v3-181", "time": 84.3433, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-182", "time": 84.7474, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-183", "time": 85.5106, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-184", "time": 85.7401, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-185", "time": 86.5134, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-186", "time": 87.1968, "lane": 1, "duration": 0.4232, "source": "sustain" }, { "id": "v3-187", "time": 87.1968, "lane": 2, "duration": 0.4232, "source": "sustain" }, { "id": "v3-188", "time": 87.7206, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-189", "time": 87.995, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-190", "time": 88.2145, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-191", "time": 88.5088, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-192", "time": 88.7882, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-193", "time": 89.5515, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-194", "time": 89.8159, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-195", "time": 90.4095, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-196", "time": 90.8136, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-197", "time": 91.0381, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-198", "time": 91.4871, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-199", "time": 91.7614, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-200", "time": 92.0109, "lane": 0, "duration": 0.3691, "source": "sustain" }, { "id": "v3-201", "time": 92.5097, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-202", "time": 92.7791, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-203", "time": 93.5174, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-204", "time": 93.737, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-205", "time": 94.274, "lane": 2, "duration": 0, "source": "drum" }], "ui": { "start": "开始过招", "loading": "音乐准备中…", "loadError": "音乐加载失败，请检查本地资源后重试。", "retry": "重试加载", "practice": "先练人声 20 秒", "practiceTag": "人声练习", "fullTag": "完整挑战", "settings": "音律设置", "close": "收好", "pause": "暂停", "resume": "继续过招", "restart": "重新开始", "home": "回到客栈", "paused": "歇一口气", "pauseHint": "音乐已暂停，继续后请重新按住未结束的长音。", "ready": "准备出指", "go": "出招", "score": "得分", "combo": "连击", "best": "本机最佳", "perfect": "绝妙", "good": "命中", "miss": "落空", "hold": "运功 · 按住", "complete": "收招", "freeze": "定", "evade": "闪", "count": "点住", "people": "位", "songEnd": "一曲终了，江湖未散", "practiceEnd": "招式已练，来场正式的", "accuracy": "准确率", "maxCombo": "最高连击", "again": "再闯一回", "volume": "音乐音量", "sfx": "点穴音效", "offset": "按键校准", "offsetHint": "在实际输出同步的基础上微调。总是按晚了可增加，按早了可减少；无法修正选错的音符。", "speed": "音符速度", "speedOptions": ["舒缓", "标准", "利落"], "calibrate": "跟拍校准", "calibrateHint": "听声音点按 8 次。画面偏移独立调整，校准结果不改写谱面。", "tap": "跟拍", "calibrationDone": "校准完成", "calibrationRetry": "偏差过大，请重新校准", "reset": "恢复默认", "accessibility": "电脑 D / F / J / K，空格暂停；手机双拇指点按。", "footer": "同人创作 · 本地成绩 · 无需登录", "noteCount": "节奏点", "durationLabel": "完整片头", "tutorialTitle": "三招，入江湖", "tutorial": [{ "name": "点", "text": "短点到金线，点一下。" }, { "name": "按", "text": "长条到金线，按住至尾部过线。" }, { "name": "合", "text": "两条长条同时到线，双指按住。" }, { "name": "齐击", "text": "两个短点同时到线，双指点下。" }], "permission": "声音需要点击后开启", "storageError": "浏览器未允许保存，当前局仍可正常游玩。", "frozenCount": "本回点住", "gradeNames": ["初入江湖", "小有所成", "点穴高手", "一代指宗"], "mute": "音效开关", "progress": "乐曲进度", "practiceHint": "人声段练习 · 不计本机纪录", "judgment": "节奏判定", "selected": "当前对手", "studioLink": "听谱与调校", "visualOffset": "画面偏移", "visualHint": "只调整音符到线的时刻，不改变按键判定。正值让画面晚到。", "guide": "节奏提示音", "guideHint": "播放谱面对应的点击声，帮助听清需要跟随的节奏。开启后不叠加命中音效。", "double": "双指合击", "resumeHold": "续住了", "doubleHold": "双指运功 · 按住", "breakHold": "运功中断", "rapPractice": "专练 Rap 32 秒", "rapPracticeHint": "说唱专项 · 不计本机纪录", "rapPracticeTag": "说唱练习", "versePractice": "Verse 逐句练习", "versePracticeHint": "按短句反复练习，提示音可在设置里开关。", "versePracticeStart": "开始这段", "versePracticeSelect": "选择乐句", "verseRepeat": "再练这段", "doubleTap": "双指齐击", "shortHold": "蓄力" }, "practiceNotes": [{ "id": "v3-22", "time": 16.0318, "lane": 1, "duration": 0, "source": "drum" }, { "id": "v3-23", "time": 16.8716, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-24", "time": 17.5202, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-25", "time": 17.7896, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-26", "time": 18.5229, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-27", "time": 19.0367, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-28", "time": 19.4857, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-29", "time": 19.7601, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-30", "time": 20.0095, "lane": 1, "duration": 0.3905, "source": "sustain" }, { "id": "v3-31", "time": 20.5084, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-32", "time": 20.7778, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-33", "time": 21.5161, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-34", "time": 21.7406, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-35", "time": 22.5238, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-36", "time": 23.2122, "lane": 1, "duration": 0.4078, "source": "sustain" }, { "id": "v3-37", "time": 23.2122, "lane": 2, "duration": 0.4078, "source": "sustain" }, { "id": "v3-38", "time": 23.741, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-39", "time": 24.0204, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-40", "time": 24.2499, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-41", "time": 24.5392, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-42", "time": 24.8136, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-43", "time": 25.5569, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-44", "time": 25.8113, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-45", "time": 26.5297, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-46", "time": 26.7741, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-47", "time": 27.0186, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-48", "time": 27.268, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-49", "time": 27.4825, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-50", "time": 27.7419, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-51", "time": 28.0063, "lane": 1, "duration": 0.3737, "source": "sustain" }, { "id": "v3-52", "time": 28.4952, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-53", "time": 28.7496, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-54", "time": 29.5029, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v3-55", "time": 29.7424, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-56", "time": 30.5406, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-57", "time": 31.0145, "lane": 1, "duration": 0.6055, "source": "sustain" }, { "id": "v3-58", "time": 31.0145, "lane": 2, "duration": 0.6055, "source": "sustain" }, { "id": "v3-59", "time": 31.7229, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v3-60", "time": 31.9973, "lane": 1, "duration": 0, "source": "vocal" }, { "id": "v3-61", "time": 32.2118, "lane": 3, "duration": 0, "source": "vocal" }, { "id": "v3-62", "time": 32.5061, "lane": 0, "duration": 0, "source": "vocal" }, { "id": "v8-smile-0", "time": 32.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-smile-1", "time": 32.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-smile-2", "time": 33.045, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-smile-3", "time": 33.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-smile-4", "time": 33.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "smile" }, { "id": "v8-response-a-0", "time": 33.795, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-response-a-1", "time": 33.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-response-a-2", "time": 34.045, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-response-a-3", "time": 34.17, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-response-a-4", "time": 34.42, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-a" }, { "id": "v8-cry-0", "time": 34.795, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-cry-1", "time": 34.92, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-cry-2", "time": 35.045, "lane": 0, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-cry-3", "time": 35.17, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-cry-4", "time": 35.42, "lane": 2, "duration": 0, "source": "vocal", "phraseId": "cry" }, { "id": "v8-response-b-0", "time": 35.795, "lane": 1, "duration": 0, "source": "vocal", "phraseId": "response-b" }, { "id": "v8-response-b-1", "time": 35.92, "lane": 3, "duration": 0, "source": "vocal", "phraseId": "response-b" }], "timingPoints": [{ "time": 0.78, "bpm": 120 }], "chartPlan": { "sections": [{ "start": 0, "end": 16.5, "source": "drum", "label": "前奏入拍" }, { "start": 16.5, "end": 32.7, "source": "vocal", "label": "兄弟相逢" }, { "start": 32.7, "end": 64.7, "source": "vocal", "label": "江湖说唱" }, { "start": 64.7, "end": 72.5, "source": "vocal", "label": "呼喊应和" }, { "start": 72.5, "end": 94.2, "source": "vocal", "label": "再聚同福" }, { "start": 94.2, "end": 98.104, "source": "drum", "label": "收招" }], "hookStarts": [16.8, 20.8, 24.8, 28.8, 64.8, 68.8, 72.8, 76.8, 80.8, 84.8, 88.8, 92.8], "hookWordOffsets": [0, 0.7, 0.96], "sustainCandidates": [[19.98, 20.42], [23.16, 23.64], [28, 28.4], [31.04, 31.64], [76.02, 76.42], [79.16, 79.64], [83.96, 84.38], [87.14, 87.64], [92.04, 92.4]], "calloutRevision": { "revision": 5, "changes": [{ "word": "来", "id": "v4-rap-9-2", "previousTime": 48.5946, "time": 48.52, "shiftMs": -74.6, "amplitude": 0.07357051826242589 }, { "word": "吧", "id": "v4-rap-9-3", "previousTime": 48.9039, "time": 48.76, "shiftMs": -143.9, "amplitude": 0.05788328698243981 }, { "word": "说", "id": "v5-callout-shuo", "previousTime": null, "time": 50.53, "shiftMs": null, "amplitude": 0.01895659872794451 }, { "word": "吧", "id": "v4-rap-10-3", "previousTime": 50.9492, "time": 50.76, "shiftMs": -189.2, "amplitude": 0.05638086115417077 }], "humanListeningApproved": false }, "onsetReview": { "revision": 6, "baseline": 5, "moves": [{ "id": "v4-rap-0-1", "time": 33.3891, "candidate": 33.3143, "shiftMs": -74.8 }, { "id": "v4-rap-0-2", "time": 33.898, "candidate": 33.8331, "shiftMs": -64.9 }, { "id": "v4-rap-0-3", "time": 34.4617, "candidate": 34.312, "shiftMs": -149.7 }, { "id": "v4-rap-1-1", "time": 35.3596, "candidate": 35.3098, "shiftMs": -49.8 }, { "id": "v4-rap-1-3", "time": 36.4372, "candidate": 36.3374, "shiftMs": -99.8 }, { "id": "v4-rap-4-0", "time": 40.6576, "candidate": 40.5628, "shiftMs": -94.8 }, { "id": "v4-rap-5-1", "time": 42.1492, "candidate": 41.9946, "shiftMs": -154.6 }, { "id": "v4-rap-6-1", "time": 44.2644, "candidate": 44.1347, "shiftMs": -129.7 }, { "id": "v4-rap-10-2", "time": 50.1061, "candidate": 50.0463, "shiftMs": -59.8 }, { "id": "v4-rap-11-1", "time": 51.6476, "candidate": 51.5179, "shiftMs": -129.7 }, { "id": "v4-rap-11-4", "time": 53.0993, "candidate": 53.0345, "shiftMs": -64.8 }, { "id": "v4-rap-12-0", "time": 53.6581, "candidate": 53.5134, "shiftMs": -144.7 }, { "id": "v4-rap-12-2", "time": 54.9501, "candidate": 54.8104, "shiftMs": -139.7 }, { "id": "v4-rap-12-3", "time": 55.3492, "candidate": 55.2445, "shiftMs": -104.7 }, { "id": "v4-rap-13-3", "time": 57.3447, "candidate": 57.2649, "shiftMs": -79.8 }, { "id": "v4-rap-13-4", "time": 57.8884, "candidate": 57.7937, "shiftMs": -94.7 }, { "id": "v4-rap-13-5", "time": 58.3674, "candidate": 58.2676, "shiftMs": -99.8 }, { "id": "v4-rap-14-3", "time": 60.1284, "candidate": 60.0685, "shiftMs": -59.9 }, { "id": "v4-rap-15-0", "time": 60.6721, "candidate": 60.5324, "shiftMs": -139.7 }], "approvedCalloutsLocked": ["v5-callout-shuo", "v4-rap-9-2", "v4-rap-9-3", "v4-rap-10-3"], "humanListeningApproved": false } }, "practiceRange": { "start": 16, "end": 36 }, "rapPracticeRange": { "start": 32.7, "end": 64.7 }, "gameTitle": "风波再起", "description": "神曲一响老白出手点住同福老友", "verseFlow": { "practiceSegments": [{ "start": 32.7, "end": 36.7, "title": "01 · 开场快读" }, { "start": 36.7, "end": 40.45, "title": "02 · 清清楚楚" }, { "start": 40.5, "end": 42.65, "title": "03 · 好久不见，你去何处" }, { "start": 42.7, "end": 47.35, "title": "04 · 应答与叠字" }, { "start": 47.7, "end": 51.15, "title": "05 · 来吧，说吧" }, { "start": 51.2, "end": 55.6, "title": "06 · 中段连句" }, { "start": 56.1, "end": 60.5, "title": "07 · 后段连句" }, { "start": 60.6, "end": 64.65, "title": "08 · 收尾连句" }] }, "playability": { "revision": 11, "sceneFreezeSeconds": 0.24, "extraNotes": [{ "id": "v11-chord-v3-146", "time": 64.7877, "lane": 2, "duration": 0, "source": "vocal" }, { "id": "v11-chord-v3-149", "time": 68.7787, "lane": 2, "duration": 0, "source": "vocal" }], "humanListeningApproved": false, "arrangement": "Continuous verse taps, two short callout holds, two call-response tap chords, existing chorus sustains.", "gapRepairs": [{ "id": "v11-fill-0", "time": 39.92, "basis": "Existing word-onset neighbourhood and continuous phrase rhythm; not listening approval" }, { "id": "v11-fill-1", "time": 47.42, "basis": "Existing word-onset neighbourhood and continuous phrase rhythm; not listening approval" }, { "id": "v11-fill-2", "time": 47.67, "basis": "Existing word-onset neighbourhood and continuous phrase rhythm; not listening approval" }, { "id": "v11-fill-3", "time": 53.92, "basis": "Existing word-onset neighbourhood and continuous phrase rhythm; not listening approval" }, { "id": "v11-fill-4", "time": 54.17, "basis": "Existing word-onset neighbourhood and continuous phrase rhythm; not listening approval" }, { "id": "v11-fill-5", "time": 55.67, "basis": "Existing word-onset neighbourhood and continuous phrase rhythm; not listening approval" }, { "id": "v11-fill-6", "time": 55.92, "basis": "Existing word-onset neighbourhood and continuous phrase rhythm; not listening approval" }, { "id": "v11-fill-7", "time": 57.67, "basis": "Existing word-onset neighbourhood and continuous phrase rhythm; not listening approval" }, { "id": "v11-toast-0", "time": 62.795, "basis": "Restore vocal events inside former character gap; aligned to existing word neighbourhoods" }, { "id": "v11-toast-1", "time": 62.92, "basis": "Restore vocal events inside former character gap; aligned to existing word neighbourhoods" }, { "id": "v11-toast-2", "time": 63.17, "basis": "Restore vocal events inside former character gap; aligned to existing word neighbourhoods" }], "holdCandidates": [{ "id": "v4-rap-9-3", "start": 48.76, "end": 49.08, "basis": "Existing callout word interval and separated-vocal RMS support; vowel continuity not heard and confirmed" }, { "id": "v4-rap-10-3", "start": 50.76, "end": 51.08, "basis": "Existing callout word interval and separated-vocal RMS support; vowel continuity not heard and confirmed" }] }, "pointing": { "revision": 1, "targets": [[0.36, 0.44], [0.32, 0.265], [0.72, 0.265], [0.7, 0.44]] } };
    const draftMode = false;
    let activePracticeRange = C.practiceRange;
    const U = C.ui, $ = s => document.querySelector(s), app = $('#app');
    document.title = C.title;
    const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    let settings = { volume: .75, sfx: true, offset: 0, visualOffset: 0, guide: false, speed: 1 }, best = 0, records = {}, storageOK = true;
    try {
        const stored = JSON.parse(localStorage.getItem('tongfu-rhythm-v1') || '{}');
        records = stored.records && typeof stored.records === 'object' ? stored.records : {};
        if (stored.best)
            records[stored.chartRevision || 2] = Math.max(Number(records[stored.chartRevision || 2]) || 0, Number(stored.best) || 0);
        best = Number(records[C.track.chartRevision]) || 0;
        const s = stored.settings || {};
        settings = { volume: Number.isFinite(Number((_a = s.volume) !== null && _a !== void 0 ? _a : .75)) ? Math.max(0, Math.min(1, Number((_b = s.volume) !== null && _b !== void 0 ? _b : .75))) : .75, sfx: s.sfx !== false, offset: stored.syncVersion === 3 ? Math.max(-250, Math.min(250, Number(s.offset) || 0)) : 0, visualOffset: Math.max(-250, Math.min(250, Number(s.visualOffset) || 0)), guide: s.guide === true, speed: [0, 1, 2].includes(s.speed) ? s.speed : 1 };
    }
    catch (_c) {
        storageOK = false;
    }
    function save() {
        try {
            records[C.track.chartRevision] = best;
            localStorage.setItem('tongfu-rhythm-v1', JSON.stringify({ best, records, chartRevision: C.track.chartRevision, syncVersion: 3, settings }));
        }
        catch (_a) {
            storageOK = false;
        }
    }
    let ctx, buffer, musicGain, source, origin = 0, position = 0, mode = 'home', practice = false, engine, limit = 0, raf = 0, countdownUntil = 0;
    let stageTimeline, currentPhrase = -1, settled = new Set(), frozen = 0, effects = [], lastFrame = 0, held = new Map(), lastFeedback = '', feedbackUntil = 0, loadPromise, calibration = null, guideTones = [];
    const asset = p => './' + p;
    const artStyle = (index, frozenState = false) => `background-image:url('${asset(C.cast[index].art)}');background-position:${frozenState ? 100 : 0}% center;${C.cast[index].homeMask ? `--cutout-mask:url('${asset(C.cast[index].homeMask)}')` : ''}`;
    const format = t => `${Math.floor(Math.max(0, t) / 60)}:${String(Math.floor(Math.max(0, t) % 60)).padStart(2, '0')}`;
    function initAudio() { if (!ctx) {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio)
            throw Error('Web Audio unavailable');
        ctx = new Audio({ latencyHint: 'interactive' });
        musicGain = ctx.createGain();
        musicGain.gain.value = settings.volume;
        musicGain.connect(ctx.destination);
        ctx.addEventListener('statechange', () => { if (ctx.state !== 'running')
            pause(); });
    } return ctx.resume(); }
    async function loadAudio() { await initAudio(); if (buffer)
        return; if (!loadPromise)
        loadPromise = new Promise((resolve, reject) => { try {
            const raw = atob(window.TONGFU_AUDIO), bytes = new Uint8Array(raw.length);
            for (let i = 0; i < raw.length; i++)
                bytes[i] = raw.charCodeAt(i);
            ctx.decodeAudioData(bytes.buffer, resolve, reject);
        }
        catch (e) {
            reject(e);
        } }).then(b => { buffer = b; window.TONGFU_AUDIO = null; }).catch(e => { loadPromise = null; throw e; }); await loadPromise; }
    function tone(frequency = 740, duration = .055, gain = .045, when = ctx === null || ctx === void 0 ? void 0 : ctx.currentTime) { if (!ctx)
        return; const osc = ctx.createOscillator(), g = ctx.createGain(); osc.type = 'sine'; osc.frequency.setValueAtTime(frequency, when); osc.frequency.exponentialRampToValueAtTime(frequency * .6, when + duration); g.gain.setValueAtTime(gain, when); g.gain.exponentialRampToValueAtTime(.001, when + duration); osc.connect(g).connect(ctx.destination); osc.onended = () => { osc.disconnect(); g.disconnect(); }; osc.start(when); osc.stop(when + duration); return osc; }
    function stopSource() { for (const o of guideTones) {
        try {
            o.stop();
        }
        catch (_a) { }
    } guideTones = []; if (source) {
        try {
            source.stop();
        }
        catch (_b) { }
        source.disconnect();
        source = null;
    } }
    function playFrom(pos, lead = 3) { stopSource(); position = pos; countdownUntil = ctx.currentTime + lead; origin = countdownUntil - pos; source = ctx.createBufferSource(); source.buffer = buffer; source.connect(musicGain); source.start(countdownUntil, pos); if (settings.guide) {
        const seen = new Set();
        for (const n of engine.notes) {
            if (n.time < pos || n.time >= limit || seen.has(n.time))
                continue;
            seen.add(n.time);
            guideTones.push(tone(n.source === 'vocal' ? 1050 : 650, .035, .045, origin + n.time));
        }
    } mode = 'countdown'; }
    function songTime(at = performance.now()) { if (mode === 'paused')
        return position; if (mode === 'countdown')
        return position; return Math.max(0, outputTime(ctx, at) - origin); }
    function cleanup() { cancelAnimationFrame(raf); stopSource(); held.clear(); calibration = null; }
    function showHome() {
        cleanup();
        mode = 'home';
        app.innerHTML = `<main class="shell home"><header class="mast"><a class="brand" href="#"><span class="seal">${C.seal}</span>${esc(C.brand)}</a><button class="icon-button" id="settings" aria-label="${U.settings}">☷</button></header><section class="hero"><div class="hero-veil"></div><div class="hero-copy"><p class="eyebrow">${C.eyebrow}</p><h1>${C.titleParts[0]}<span>${C.titleParts[1]}</span></h1><p class="tagline">${C.subtitle}</p></div><div class="year-stamp">${C.yearStamp}<span>${C.yearLabel}</span></div><div class="roster">${C.cast.map((p, i) => `<div class="roster-person"><div class="sprite${p.homeMask ? ' cutout' : ''}" style="background-image:url('${asset(p.homeArt)}')"></div><span>${p.name}</span></div>`).join('')}</div><div class="hero-bottom"><span>✦ ${C.anniversary}</span><span>${C.heroCaption}</span></div></section><section class="home-body"><div class="track-card"><div class="record"><span>${C.recordLabel}</span></div><div class="track-copy"><h2>${C.track.title}<span>${C.track.artist}</span></h2><p>${draftMode ? C.studio.draftTag : C.track.version} · ${C.track.bpm} BPM</p></div><div class="track-time">${C.displayDuration}<small>${U.durationLabel}</small></div></div><div class="stats-strip"><span>${C.notes.length} <small>${U.noteCount}</small></span><i></i><span>4 <small>${C.laneLabel}</small></span><i></i><span>${Math.floor(best).toLocaleString()} <small>${U.best}</small></span></div><button class="primary start" id="start">${U.start}<span>→</span></button><div class="secondary-row"><button class="text-button" id="practice">▷ ${U.practice}</button><button class="text-button" id="howto">${U.tutorialTitle} ↗</button></div><button class="text-button rap-practice" id="rap-practice">▷ ${U.rapPractice}</button><button class="text-button rap-practice" id="verse-practice">${U.versePractice}</button><div class="tutorial">${U.tutorial.map((t, i) => `<div><span class="tutorial-symbol symbol-${i}">${t.name}</span><p>${t.text}</p></div>`).join('')}</div><p class="keyboard-hint">${U.accessibility}</p><footer>${U.footer}</footer>${storageOK ? '' : `<p class="notice">${U.storageError}</p>`}</section></main>`;
        $('.brand').onclick = e => e.preventDefault();
        $('#start').onclick = () => begin(false);
        $('#practice').onclick = () => begin(true);
        $('#rap-practice').onclick = () => begin(true, C.rapPracticeRange);
        $('#verse-practice').onclick = showVersePractice;
        $('#settings').onclick = showSettings;
        $('#howto').onclick = () => showInfo();
    }
    function showVersePractice() { const d = openDialog(`<h2>${U.versePractice}</h2><p>${U.versePracticeHint}</p><label class="setting-label" for="verse-segment">${U.versePracticeSelect}</label><select id="verse-segment" class="verse-select">${C.verseFlow.practiceSegments.map((s, i) => `<option value="${i}">${esc(s.title)}</option>`).join('')}</select><button class="primary" id="verse-start">${U.versePracticeStart}</button><button class="text-button" data-close>${U.close}</button>`); $('#verse-start').onclick = () => { const range = C.verseFlow.practiceSegments[Number($('#verse-segment').value)]; d.close(); begin(true, range); }; }
    function showInfo() { openDialog(`<h2>${U.tutorialTitle}</h2>${U.tutorial.map(t => `<p class="help-line"><strong>${t.name}</strong>${t.text}</p>`).join('')}<p class="muted">${U.accessibility}</p><button class="primary" data-close>${U.close}</button>`); }
    function openDialog(body) { const old = $('dialog'); old === null || old === void 0 ? void 0 : old.remove(); const d = document.createElement('dialog'); d.innerHTML = `<div class="dialog-inner">${body}</div>`; app.append(d); if (d.showModal)
        d.showModal();
    else {
        d.setAttribute('open', '');
        d.classList.add('dialog-fallback');
        d.close = function () { d.dispatchEvent(new Event('close')); d.remove(); };
    } d.querySelectorAll('[data-close]').forEach(b => b.onclick = () => (d.close ? d.close() : d.remove())); d.addEventListener('close', () => { if (calibration === null || calibration === void 0 ? void 0 : calibration.tones)
        for (const o of calibration.tones) {
            try {
                o.stop();
            }
            catch (_a) { }
        } calibration = null; d.remove(); }); return d; }
    function showSettings() {
        if (mode === 'playing' || mode === 'countdown')
            pause();
        const d = openDialog(`<div class="dialog-heading"><h2>${U.settings}</h2><button class="icon-button" data-close aria-label="${U.close}">×</button></div><label class="setting-label">${U.volume}<output id="volume-value">${Math.round(settings.volume * 100)}%</output></label><input aria-label="${U.volume}" id="volume" type="range" min="0" max="1" step=".01" value="${settings.volume}"><label class="switch-row">${U.sfx}<input type="checkbox" id="sfx" ${settings.sfx ? 'checked' : ''}></label><label class="setting-label">${U.offset}<output id="offset-value">${settings.offset} ms</output></label><input aria-label="${U.offset}" id="offset" type="range" min="-250" max="250" step="5" value="${settings.offset}"><p class="muted">${U.offsetHint}</p><label class="setting-label">${U.visualOffset}<output id="visual-value">${settings.visualOffset} ms</output></label><input aria-label="${U.visualOffset}" id="visual-offset" type="range" min="-250" max="250" step="5" value="${settings.visualOffset}"><p class="muted">${U.visualHint}</p><label class="switch-row">${U.guide}<input type="checkbox" id="guide" ${settings.guide ? 'checked' : ''}></label><p class="muted">${U.guideHint}</p><label class="setting-label">${U.speed}</label><div class="speed-options">${U.speedOptions.map((s, i) => `<button data-speed="${i}" class="${settings.speed === i ? 'selected' : ''}">${s}</button>`).join('')}</div><button id="calibrate" class="secondary">${U.calibrate}</button><p id="calibration-status" class="muted">${U.calibrateHint}</p><button id="tap" class="primary" hidden>${U.tap} <span id="tap-count">0 / 8</span></button><button id="reset" class="text-button">${U.reset}</button>`);
        $('#volume').oninput = e => { settings.volume = Number(e.target.value); $('#volume-value').textContent = `${Math.round(settings.volume * 100)}%`; if (musicGain)
            musicGain.gain.value = settings.volume; save(); };
        $('#sfx').onchange = e => { settings.sfx = e.target.checked; save(); };
        $('#offset').oninput = e => { settings.offset = Number(e.target.value); $('#offset-value').textContent = `${settings.offset} ms`; save(); };
        d.querySelectorAll('[data-speed]').forEach(b => b.onclick = () => { settings.speed = Number(b.dataset.speed); d.querySelectorAll('[data-speed]').forEach(x => x.classList.toggle('selected', x === b)); save(); });
        $('#visual-offset').oninput = e => { settings.visualOffset = Number(e.target.value); $('#visual-value').textContent = `${settings.visualOffset} ms`; save(); };
        $('#guide').onchange = e => { settings.guide = e.target.checked; save(); };
        $('#reset').onclick = () => { settings = { volume: .75, sfx: true, offset: 0, visualOffset: 0, guide: false, speed: 1 }; save(); if (musicGain)
            musicGain.gain.value = .75; d.close(); showSettings(); };
        $('#calibrate').onclick = async () => { await initAudio(); if (calibration === null || calibration === void 0 ? void 0 : calibration.tones)
            for (const o of calibration.tones) {
                try {
                    o.stop();
                }
                catch (_a) { }
            } const start = ctx.currentTime + 1; calibration = { start, samples: [], used: new Set(), tones: [] }; for (let i = 0; i < 12; i++)
            calibration.tones.push(tone(880, .065, .12, start + i * .65)); $('#tap').hidden = false; $('#tap-count').textContent = '0 / 8'; };
        $('#tap').onpointerdown = e => { e.preventDefault(); if (!calibration)
            return; const index = Math.round((outputTime(ctx, e.timeStamp) - calibration.start) / .65); if (index < 0 || index > 11 || calibration.used.has(index))
            return; calibration.used.add(index); calibration.samples.push((outputTime(ctx, e.timeStamp) - calibration.start - index * .65) * 1000); $('#tap-count').textContent = `${calibration.samples.length} / 8`; if (calibration.samples.length === 8) {
            const value = medianOffset(calibration.samples);
            if (value !== null) {
                settings.offset = value;
                save();
                $('#offset').value = value;
                $('#offset-value').textContent = `${value} ms`;
                $('#calibration-status').textContent = U.calibrationDone;
            }
            else
                $('#calibration-status').textContent = U.calibrationRetry;
            for (const o of calibration.tones) {
                try {
                    o.stop();
                }
                catch (_a) { }
            }
            calibration = null;
            $('#tap').hidden = true;
        } };
    }
    async function begin(isPractice, range = C.practiceRange) {
        if (mode === 'loading')
            return;
        mode = 'loading';
        const btn = $(isPractice ? '#practice' : '#start');
        if (btn) {
            btn.disabled = true;
            btn.textContent = U.loading;
        }
        try {
            await loadAudio();
        }
        catch (_a) {
            mode = 'home';
            if (btn) {
                btn.disabled = false;
                btn.textContent = U.retry;
            }
            openDialog(`<p>${U.loadError}</p><button data-close class="primary">${U.close}</button>`);
            return;
        }
        practice = isPractice;
        activePracticeRange = range;
        limit = practice ? range.end : buffer.duration;
        engine = new RhythmEngine(practice ? C.notes.filter(n => n.time >= range.start && n.time + n.duration < range.end) : C.notes, C.rules);
        currentPhrase = -1;
        stageTimeline = new StageTimeline(C.phrases, C.playability.sceneFreezeSeconds);
        settled = stageTimeline.settled;
        frozen = 0;
        effects = [];
        lastFeedback = '';
        held.clear();
        renderGame();
        playFrom(practice ? activePracticeRange.start : 0);
        lastFrame = performance.now();
        raf = requestAnimationFrame(frame);
    }
    function renderGame() {
        app.innerHTML = `<main class="shell game"><header class="game-header"><div class="score-box"><small>${U.score}</small><strong id="score">000000</strong></div><div class="game-title">${C.gameTitle}<small>${draftMode ? C.studio.draftTag : practice ? (activePracticeRange.title || (activePracticeRange === C.rapPracticeRange ? U.rapPracticeTag : U.practiceTag)) : C.track.title}</small></div><button id="pause" class="icon-button" aria-label="${U.pause}">Ⅱ</button></header><div class="progress" role="progressbar" aria-label="${U.progress}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="progress-fill"></div></div><section class="stage"><div class="stage-shade"></div><div class="opponent-label"><small id="role"></small><h2 id="character-name"></h2></div><div class="round-label"><span id="phrase-title"></span><small><span id="frozen-count">0</span> ${U.people}${U.count}</small></div><div class="fighter" id="fighter"><div class="sprite" id="fighter-sprite"></div><span id="freeze-seal">${U.freeze}</span></div><canvas id="effects" aria-hidden="true"></canvas><div class="stage-caption" id="stage-caption"></div><div class="combo-box"><strong id="combo">0</strong><span>${U.combo}</span></div><div class="judgment" id="judgment" aria-live="off"></div></section><section class="playfield" aria-label="${U.judgment}"><canvas id="notes" aria-hidden="true"></canvas><div class="track-grid">${C.lanes.map((_, i) => `<div class="lane-glow" data-glow="${i}"></div>`).join('')}</div><div class="judgment-line"></div><div class="key-row">${C.lanes.map((l, i) => `<button class="lane-key" data-lane="${i}" style="--lane-color:${l.color}" aria-label="${l.label} ${l.key}"><span class="key-ring"></span><span class="key-label">${l.label}</span><kbd>${l.key}</kbd></button>`).join('')}</div></section><div class="game-bottom"><span id="elapsed">0:00</span><span>${draftMode ? C.studio.previewHint : practice ? (activePracticeRange.title ? U.versePracticeHint : (activePracticeRange === C.rapPracticeRange ? U.rapPracticeHint : U.practiceHint)) : U.accessibility}</span><span>${format(limit - (practice ? activePracticeRange.start : 0))}</span></div><div class="countdown-overlay" id="countdown"><small>${U.ready}</small><strong id="countdown-number">3</strong></div><div class="pause-overlay" id="pause-panel" hidden><div class="pause-card"><span class="small-seal">${C.restSeal}</span><h2>${U.paused}</h2><p>${U.pauseHint}</p><button class="primary" id="resume">${U.resume}</button><button class="secondary" id="pause-settings">${U.settings}</button><div class="secondary-row"><button class="text-button" id="restart">${U.restart}</button><button class="text-button" id="home">${U.home}</button></div></div></div></main>`;
        $('#pause').onclick = pause;
        $('#resume').onclick = resume;
        $('#restart').onclick = () => { cleanup(); begin(practice, activePracticeRange); };
        $('#home').onclick = showHome;
        $('#pause-settings').onclick = showSettings;
        document.querySelectorAll('[data-lane]').forEach(b => { b.onpointerdown = e => { e.preventDefault(); if (mode !== 'playing')
            return; b.setPointerCapture(e.pointerId); press(Number(b.dataset.lane), 'p' + e.pointerId, e.timeStamp); }; b.onpointermove = e => { const r = b.getBoundingClientRect(); if (e.clientX < r.left - 22 || e.clientX > r.right + 22 || e.clientY < r.top - 22 || e.clientY > r.bottom + 22)
            release('p' + e.pointerId, e.timeStamp); }; b.onpointerup = e => release('p' + e.pointerId, e.timeStamp); b.onpointercancel = e => release('p' + e.pointerId, e.timeStamp); b.onlostpointercapture = e => release('p' + e.pointerId, e.timeStamp); b.oncontextmenu = e => e.preventDefault(); });
        setCharacter(0);
    }
    function press(lane, id, at = performance.now()) { if (mode !== 'playing' || held.has(id) || [...held.values()].includes(lane))
        return; held.set(id, lane); const n = engine.hit(lane, songTime(at) - settings.offset / 1000); if (!n && settings.sfx)
        tone(180, .025, .012); updatePressed(); processEvents(); }
    function release(id, at = performance.now()) { if (!held.has(id))
        return; const lane = held.get(id); held.delete(id); if (mode === 'playing')
        engine.release(lane, songTime(at) - settings.offset / 1000); updatePressed(); processEvents(); }
    function updatePressed() { document.querySelectorAll('[data-lane]').forEach(b => b.classList.toggle('pressed', [...held.values()].includes(Number(b.dataset.lane)))); document.querySelectorAll('[data-glow]').forEach(b => b.classList.toggle('active', [...held.values()].includes(Number(b.dataset.glow)))); }
    function pause() { if (!['playing', 'countdown'].includes(mode))
        return; position = songTime(); stopSource(); mode = 'paused'; held.clear(); engine.suspend(position - settings.offset / 1000); processEvents(); updatePressed(); $('#pause-panel').hidden = false; $('#countdown').hidden = true; }
    async function resume() { await initAudio(); $('#pause-panel').hidden = true; for (const n of engine.notes)
        if (n.status === 'suspended')
            n.resumeDeadline = position - settings.offset / 1000 + .35; playFrom(position, 3); }
    function setCharacter(i) { const phrase = C.phrases[i], p = C.cast[phrase.cast]; $('#fighter-sprite').style.cssText = artStyle(p.pos); $('#fighter').className = 'fighter entering'; $('#character-name').textContent = p.name; $('#role').textContent = p.role; $('#phrase-title').textContent = phrase.title; $('#stage-caption').textContent = p.line; $('#freeze-seal').textContent = U.freeze; }
    function animateHit(el, strong = false) { if (!el || matchMedia('(prefers-reduced-motion: reduce)').matches)
        return; if (!el.animate)
        return; if (el.getAnimations)
        el.getAnimations().forEach(a => a.cancel()); el.animate([{ filter: 'brightness(1.65)', translate: '0 0' }, { filter: 'brightness(1.15)', translate: strong ? '0 3px' : '0 1px' }, { filter: 'brightness(1)', translate: '0 0' }], { duration: strong ? 210 : 110, easing: 'ease-out' }); }
    function processEvents() {
        if (!engine)
            return;
        const events = engine.drain();
        if (!events.length)
            return;
        const priority = { miss: 1, break: 2, resume: 3, good: 4, perfect: 5, complete: 6, double: 7 };
        const winner = events.reduce((a, b) => priority[b.type] > priority[a.type] ? b : a);
        const labels = { break: U.breakHold, resume: U.resumeHold, double: U.double };
        lastFeedback = winner.type === 'double' && winner.tap ? U.doubleTap : (labels[winner.type] || U[winner.type]);
        feedbackUntil = performance.now() + (winner.type === 'double' ? 600 : winner.type === 'complete' ? 420 : 240);
        const judgment = $('#judgment');
        if (judgment) {
            judgment.classList.toggle('miss', ['miss', 'break'].includes(winner.type));
            judgment.dataset.kind = winner.type;
            animateHit(judgment, ['complete', 'double'].includes(winner.type));
        }
        const hasDouble = events.some(e => e.type === 'double');
        for (const event of events) {
            if (['miss', 'break', 'resume'].includes(event.type))
                continue;
            if (hasDouble && event.type === 'complete')
                continue;
            const strong = ['double', 'complete'].includes(event.type), [x, y] = C.lanes[event.lane].target;
            effects.push({ start: performance.now(), x, y, lane: event.lane, strong, kind: event.type });
            animateHit($(`[data-lane="${event.lane}"]`), strong);
            if (event.type === 'double')
                for (const n of engine.notes.filter(n => n.duration && n.status === 'done' && Math.abs(n.time - engine.notes.find(n => n.id === event.id).time) < .001))
                    animateHit($(`[data-lane="${n.lane}"]`), true);
        }
        if (!['miss', 'break', 'resume'].includes(winner.type)) {
            const fighter = $('#fighter');
            if (fighter && !fighter.classList.contains('frozen'))
                animateHit($('#fighter-sprite'), ['complete', 'double'].includes(winner.type));
            if (settings.sfx && !settings.guide) {
                const type = winner.type;
                tone(type === 'double' ? 1100 : type === 'complete' ? 820 : type === 'perfect' ? 1300 : 760, type === 'double' ? .09 : .035, type === 'double' ? .045 : .026);
                if (type === 'double')
                    tone(550, .085, .025);
            }
        }
    }
    function canvasContext(id) { const canvas = $(id), r = canvas.getBoundingClientRect(), dpr = Math.min(devicePixelRatio || 1, 2); if (canvas.width !== Math.round(r.width * dpr) || canvas.height !== Math.round(r.height * dpr)) {
        canvas.width = Math.round(r.width * dpr);
        canvas.height = Math.round(r.height * dpr);
    } const g = canvas.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, r.width, r.height); return { g, w: r.width, h: r.height }; }
    function roundRect(g, x, y, w, h, r) { g.beginPath(); h = Math.max(1, h); r = Math.min(r, w / 2, h / 2); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
    function drawNotes(t) {
        const { g, w, h } = canvasContext('#notes');
        const bottom = 74, line = h - bottom, travel = [2.2, 1.75, 1.35][settings.speed], px = line / travel, laneW = w / 4;
        for (let i = 0; i < 4; i++) {
            const x = laneW * (i + .5);
            g.strokeStyle = 'rgba(232,198,139,.12)';
            g.lineWidth = 1;
            g.beginPath();
            g.moveTo(i * laneW, 0);
            g.lineTo(i * laneW, h);
            g.stroke();
            g.fillStyle = 'rgba(243,199,129,.07)';
            g.beginPath();
            g.arc(x, line, 19, 0, Math.PI * 2);
            g.fill();
        }
        for (const e of effects) {
            const age = (performance.now() - e.start) / (e.strong ? 300 : 170);
            if (age < 0 || age > 1)
                continue;
            g.save();
            g.globalAlpha = (1 - age) * .85;
            g.fillStyle = C.lanes[e.lane].color;
            roundRect(g, laneW * e.lane + 8, line - 5, laneW - 16, 10, 5);
            g.fill();
            g.strokeStyle = '#fff1c9';
            g.lineWidth = 2;
            g.beginPath();
            g.arc(laneW * (e.lane + .5), line, 16 + age * (e.strong ? 24 : 12), 0, Math.PI * 2);
            g.stroke();
            g.restore();
        }
        for (const n of engine.notes.filter(n => n.status === 'holding')) {
            const progress = Math.max(0, Math.min(1, (songTime() - settings.offset / 1000 - n.time) / n.duration));
            g.strokeStyle = C.lanes[n.lane].color;
            g.lineWidth = 4;
            g.beginPath();
            g.arc(laneW * (n.lane + .5), line, 24, -Math.PI / 2, -Math.PI / 2 + progress * Math.PI * 2);
            g.stroke();
        }
        for (const n of engine.notes) {
            if (['done', 'miss', 'broken'].includes(n.status))
                continue;
            const y = line - (n.time - t) * px;
            if (y < -n.duration * px - 30 || y > h + n.duration * px)
                continue;
            const x = laneW * (n.lane + .5), color = C.lanes[n.lane].color;
            g.save();
            g.shadowColor = color;
            g.shadowBlur = n.status === 'holding' ? 17 : 8;
            if (n.duration) {
                const tail = line - (n.time + n.duration - t) * px, head = ['holding', 'suspended'].includes(n.status) ? line : y;
                const top = Math.max(-10, tail);
                g.fillStyle = color + '55';
                roundRect(g, x - 13, top, 26, Math.max(1, head - top), 7);
                g.fill();
                g.strokeStyle = color;
                g.lineWidth = 2;
                g.beginPath();
                g.moveTo(x - 13, top);
                g.lineTo(x - 13, head);
                g.moveTo(x + 13, top);
                g.lineTo(x + 13, head);
                g.stroke();
                for (let tick = n.time; tick <= n.time + n.duration; tick += .5) {
                    const ty = line - (tick - t) * px;
                    if (ty >= top && ty <= head) {
                        g.fillStyle = color;
                        g.fillRect(x - 9, ty, 18, 2);
                    }
                }
                g.fillStyle = color;
                roundRect(g, x - 20, tail - 3, 40, 6, 3);
                g.fill();
            }
            const hy = ['holding', 'suspended'].includes(n.status) ? line : y;
            g.fillStyle = color;
            roundRect(g, x - 29, hy - 7, 58, 14, 5);
            g.fill();
            g.fillStyle = '#fff4d9';
            roundRect(g, x - 20, hy - 4, 40, 3, 2);
            g.fill();
            if (n.duration) {
                g.fillStyle = '#15202a';
                g.beginPath();
                g.arc(x, hy, 3, 0, Math.PI * 2);
                g.fill();
            }
            g.restore();
        }
    }
    function drawPointingHand(g, x, y, side, scale, alpha) {
        g.save();
        g.translate(x, y);
        g.scale(side * scale, scale);
        g.globalAlpha = alpha;
        g.lineJoin = 'round';
        g.lineCap = 'round';
        g.lineWidth = 1.7;
        g.strokeStyle = '#35271f';
        g.fillStyle = '#394e66';
        g.beginPath();
        g.moveTo(-91, 12);
        g.lineTo(-61, 8);
        g.lineTo(-56, 31);
        g.lineTo(-88, 39);
        g.closePath();
        g.fill();
        g.stroke();
        g.fillStyle = '#eed7ac';
        g.beginPath();
        g.moveTo(-64, 9);
        g.lineTo(-57, 8);
        g.lineTo(-51, 30);
        g.lineTo(-58, 33);
        g.closePath();
        g.fill();
        g.stroke();
        g.fillStyle = '#edb98d';
        g.beginPath();
        g.moveTo(-57, 11);
        g.quadraticCurveTo(-49, 3, -35, 1);
        g.lineTo(-6, -4);
        g.quadraticCurveTo(1, -5, 1, 0);
        g.quadraticCurveTo(1, 3, -5, 4);
        g.lineTo(-29, 8);
        g.lineTo(-4, 5);
        g.quadraticCurveTo(3, 5, 2, 10);
        g.quadraticCurveTo(2, 13, -4, 13);
        g.lineTo(-28, 15);
        g.quadraticCurveTo(-23, 18, -28, 24);
        g.quadraticCurveTo(-32, 33, -44, 32);
        g.lineTo(-53, 28);
        g.closePath();
        g.fill();
        g.stroke();
        g.strokeStyle = '#a26a4c';
        g.lineWidth = 1.1;
        g.beginPath();
        g.moveTo(-42, 12);
        g.quadraticCurveTo(-26, 12, -31, 22);
        g.moveTo(-39, 23);
        g.lineTo(-31, 25);
        g.moveTo(-12, 0);
        g.lineTo(-7, -1);
        g.moveTo(-11, 9);
        g.lineTo(-5, 9);
        g.stroke();
        g.restore();
    }
    function drawEffects(now) {
        const { g, w, h } = canvasContext('#effects'), canvas = $('#effects').getBoundingClientRect(), body = $('#fighter').getBoundingClientRect();
        const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
        effects = effects.filter(e => now - e.start < 260);
        const active = engine.notes.filter(n => n.status === 'holding');
        for (let lane = 0; lane < 4; lane++) {
            const target = C.pointing.targets[lane], x = body.left - canvas.left + body.width * target[0], y = body.top - canvas.top + body.height * target[1], color = C.lanes[lane].color;
            const hit = effects.filter(e => e.lane === lane).slice(-1)[0], holding = active.find(n => n.lane === lane), age = hit ? now - hit.start : 999;
            const lit = Boolean(holding) || age < 210, side = lane < 2 ? 1 : -1;
            g.save();
            g.globalAlpha = lit ? 1 : .58;
            g.fillStyle = lit ? '#fff3ce' : '#18212a';
            g.strokeStyle = color;
            g.lineWidth = lit ? 2 : 1;
            g.beginPath();
            g.arc(x, y, lit ? 5 : 3.5, 0, Math.PI * 2);
            g.fill();
            g.stroke();
            if (lit) {
                const progress = holding ? Math.max(0, Math.min(1, (songTime() - settings.offset / 1000 - holding.time) / holding.duration)) : 1;
                g.lineWidth = 2;
                g.beginPath();
                g.arc(x, y, 10, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * progress);
                g.stroke();
                if (age < 100 && !reduced) {
                    for (let k = 0; k < 4; k++) {
                        const angle = k * Math.PI / 2 + Math.PI / 4;
                        g.beginPath();
                        g.moveTo(x + Math.cos(angle) * 13, y + Math.sin(angle) * 13);
                        g.lineTo(x + Math.cos(angle) * 18, y + Math.sin(angle) * 18);
                        g.stroke();
                    }
                }
            }
            g.restore();
            if (holding || age < 260) {
                const retreat = holding || reduced ? 0 : Math.max(0, (age - 85) / 175), alpha = holding ? 1 : 1 - retreat;
                drawPointingHand(g, x - side * retreat * 28, y + retreat * 9, side, Math.max(.62, Math.min(.9, h / 230)), alpha);
            }
        }
    }
    function frame(now) {
        if (!['playing', 'countdown', 'paused'].includes(mode))
            return;
        const gap = now - lastFrame;
        lastFrame = now;
        if (mode === 'playing' && gap > 900)
            pause();
        if (mode === 'countdown' && outputTime(ctx) >= countdownUntil) {
            mode = 'playing';
            $('#countdown').hidden = true;
        }
        if (mode === 'countdown') {
            $('#countdown').hidden = false;
            $('#countdown-number').textContent = Math.max(1, Math.ceil(countdownUntil - outputTime(ctx)));
        }
        const t = songTime(), judge = t - settings.offset / 1000;
        if (mode === 'playing') {
            engine.update(judge);
            processEvents();
            if (t >= limit) {
                finish();
                return;
            }
        }
        const stage = stageTimeline.update(engine, t, judge, mode === 'playing');
        if (stage.entered !== null) {
            currentPhrase = stage.entered;
            setCharacter(currentPhrase);
        }
        for (const result of stage.results) {
            if (!result.visible)
                continue;
            const phrase = C.phrases[result.index];
            $('#fighter').classList.add(result.success ? 'frozen' : 'evaded');
            if (result.success)
                $('#fighter-sprite').style.cssText = artStyle(C.cast[phrase.cast].pos, true);
            $('#freeze-seal').textContent = result.success ? U.freeze : U.evade;
        }
        frozen = stageTimeline.frozen;
        const section = C.chartPlan.sections.find(s => s.start <= t && s.end > t);
        if (section)
            $('#phrase-title').textContent = section.label;
        $('#score').textContent = String(Math.floor(engine.score)).padStart(6, '0');
        $('#combo').textContent = engine.combo;
        $('#frozen-count').textContent = frozen;
        $('#elapsed').textContent = format(t - (practice ? activePracticeRange.start : 0));
        $('#progress-fill').style.width = `${Math.min(100, Math.max(0, (t - (practice ? activePracticeRange.start : 0)) / (limit - (practice ? activePracticeRange.start : 0)) * 100))}%`;
        $('.progress').setAttribute('aria-valuenow', String(Math.round(Math.max(0, (t - (practice ? activePracticeRange.start : 0)) / (limit - (practice ? activePracticeRange.start : 0)) * 100))));
        if (now >= feedbackUntil) {
            $('#judgment').classList.remove('miss');
            $('#judgment').dataset.kind = 'sustain';
        }
        $('#judgment').textContent = now < feedbackUntil ? lastFeedback : engine.notes.filter(n => n.status === 'holding').length >= 2 ? U.doubleHold : engine.notes.some(n => n.status === 'holding') ? U.hold : '';
        drawNotes(t - settings.visualOffset / 1000);
        drawEffects(now);
        raf = requestAnimationFrame(frame);
    }
    function finish() {
        engine.update(limit + C.rules.good + .01);
        processEvents();
        for (let i = 0; i < C.phrases.length; i++) {
            const p = C.phrases[i];
            if (p.start >= limit)
                continue;
            if (!settled.has(i) && engine.phraseSuccess(p.start, Math.min(p.end, limit)))
                frozen++;
        }
        cleanup();
        mode = 'result';
        if (!practice && !draftMode) {
            best = Math.max(best, Math.floor(engine.score));
            save();
        }
        const grade = engine.accuracy >= 95 ? 3 : engine.accuracy >= 80 ? 2 : engine.accuracy >= 55 ? 1 : 0;
        app.innerHTML = `<main class="shell result"><header class="mast"><span class="brand"><span class="seal">${C.seal}</span>${C.brand}</span><span class="muted">${draftMode ? C.studio.draftTag : practice ? (activePracticeRange.title || (activePracticeRange === C.rapPracticeRange ? U.rapPracticeTag : U.practiceTag)) : C.track.title}</span></header><section class="result-content"><p class="eyebrow">${practice ? U.practiceEnd : U.songEnd}</p><div class="result-seal">${C.resultSeals[grade]}</div><h1>${U.gradeNames[grade]}</h1><div class="result-score">${Math.floor(engine.score).toLocaleString()}<small>${U.score}</small></div><div class="result-stats"><div><strong>${engine.accuracy.toFixed(1)}<small>%</small></strong><span>${U.accuracy}</span></div><div><strong>${engine.maxCombo}</strong><span>${U.maxCombo}</span></div><div><strong>${frozen}</strong><span>${U.frozenCount}</span></div></div><div class="judgment-summary"><span>${U.perfect}<b>${engine.counts.perfect}</b></span><span>${U.good}<b>${engine.counts.good}</b></span><span>${U.miss}<b>${engine.counts.miss}</b></span></div><div class="result-roster">${C.cast.map((p, i) => `<div class="sprite" style="${artStyle(i)}"></div>`).join('')}</div><button class="primary" id="again">${practice ? U.verseRepeat : U.again} →</button><button class="text-button" id="back">${U.home}</button><p class="muted">${practice ? (activePracticeRange.title ? U.versePracticeHint : (activePracticeRange === C.rapPracticeRange ? U.rapPracticeHint : U.practiceHint)) : `${U.best} · ${best.toLocaleString()}`}</p></section><footer>${U.footer}</footer></main>`;
        $('#again').onclick = () => begin(practice, activePracticeRange);
        $('#back').onclick = showHome;
    }
    document.addEventListener('keydown', e => { if ($('dialog') || ['INPUT', 'TEXTAREA'].includes(e.target.tagName))
        return; if (e.code === 'Space' && ['playing', 'paused', 'countdown'].includes(mode)) {
        e.preventDefault();
        if (!e.repeat)
            (mode === 'paused' ? resume() : pause());
        return;
    } const lane = C.lanes.findIndex(l => 'Key' + l.key === e.code); if (lane >= 0 && mode === 'playing') {
        e.preventDefault();
        if (!e.repeat)
            press(lane, 'k' + e.code, e.timeStamp);
    } });
    document.addEventListener('keyup', e => release('k' + e.code, e.timeStamp));
    document.addEventListener('visibilitychange', () => { if (document.hidden)
        pause(); });
    window.addEventListener('blur', () => pause());
    window.addEventListener('pagehide', () => { pause(); save(); });
    showHome();
})();
